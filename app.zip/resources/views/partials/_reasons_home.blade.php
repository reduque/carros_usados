<section class="cu-reasons">
    <div class="cu-container">
        <div class="cu-reasons__intro">
            <h2>¿Por qué CarrosUsados?</h2>
            <p>Porque tenemos <strong>los mejores precios</strong>, pero además:</p>
        </div>
        <ol class="cu-reasons__reasons">
            <li>
                <h3>Documentación legal del vehículo</h3>
                <p>Garantizamos toda la documentación correspondiente de  su vehículo.</p>
            </li>
            <li>
                <h3>Formas seguras de pago</h3>
                <p>Siéntase cómodo y seguro al momento de realizar su pago.</p>
            </li>
            <li>
                <h3>Entrega a domicilio</h3>
                <p>Próximamente haremos entregas a domicilio en toda la ciudad de Caracas.</p>
            </li>
        </ol>
    </div>
</section>