<div class="cu-modal">
    <div class="cu-modal__container">
        <button class="cu-button cu-modal__close">Cerrar</button>
        @include('partials._puntos')
    </div>
</div>