@extends('layouts.front')

@section('css')

@endsection

@section('content')

@include('partials._hero')
@include('partials._catalog_home')
@include('partials._reasons_home')
@include('partials._cert_home')

@endsection
@section('javascript')

@endsection