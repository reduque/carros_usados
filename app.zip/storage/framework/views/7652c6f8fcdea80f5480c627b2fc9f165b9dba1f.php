

<?php $__env->startSection('content'); ?>
<div class="internas">
    <h1>Ha ocurrido un error</h1>
    <p>Pasó mucho tiempo y su información se ha perdido</p>
    <p>
        <a href="<?php echo e(route('home')); ?>" class="amarillo">Ir a la página de incio</a>
    </p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\charcuteria_tovar\resources\views/errors/419.blade.php ENDPATH**/ ?>