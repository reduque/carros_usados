

<?php $__env->startSection('content'); ?>
<div class="internas">
    <h1>Mis compras</h1>
    <div class="espaciado">
    <?php if($ordenes->count() == 0): ?>
        <h3>Aún no tienes compras</h3>
        <br>
        <p>
            <a href="<?php echo e(route('productos')); ?>" class="botones">Ver nuestros productos</a>
        </p>
    <?php else: ?>
        <?php $__currentLoopData = $ordenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orden): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>
                <table class="b_resaltado">
                    <tr>
                        <td>
                            <b>Fecha de compra: </b> <?php echo e($orden->fecha); ?>

                            <br>
                            <b>Tipo de entrega:</b> <?php echo e($orden->tipo_entrega); ?>

                            <br>
                            <b>Forma de pago: </b> <?php echo e($orden->forma_pago); ?>

                        </td>
                        <td>
                            <b>N. orden:</b> <?php echo e(str_pad($orden->id,5,"0",STR_PAD_LEFT)); ?>

                            <br>
                            <b>Estado: </b> <?php echo e($orden->estado_real); ?>

                            <?php if($orden->estado==0): ?>
                                <p><a href="<?php echo e(route('editar_orden', codifica($orden->id))); ?>" class="botones">Editar orden</a></p>
                            <?php endif; ?>
                        </td>
                    </tr>
                </table>
                <br>
                <table>
                    <thead>
                        <tr>
                            <th>Producto</th>
                            <th class="centrar">Cantidad</th>
                            <th class="centrar">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $orden->productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><a href="<?php echo e(route('producto', $producto->producto->slug )); ?>"><?php echo e($producto->producto->nombre); ?></a></td>
                                <td class="centrar peq"><?php echo e($producto->cantidad); ?></td>
                                <td class="derecha peq">$ <?php echo e(number_format($producto->total,2,",",".")); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="derecha" colspan="2"><b>Subtotal<br>Delivery<br>Total</b></td>
                            <td class="derecha peq"><b>$ <?php echo e(number_format( $orden->subtotal ,2,",",".")); ?><br>$ <?php echo e(number_format( $orden->delirery ,2,",",".")); ?><br>$ <?php echo e(number_format( $orden->total ,2,",",".")); ?></b></td>
                        </tr>
                    </tbody>
                </table>
                <hr>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\tienda_ananke\resources\views/mis_compras.blade.php ENDPATH**/ ?>