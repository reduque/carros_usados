

<?php $__env->startSection('content'); ?>
<!--
<div class="bannerhome">
    <div>
        <h1>tienda ananké</h1>
    </div>
</div>
-->
<div class="banners_home2">
    <div class="contenedor">
    <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="item">
        <?php if($banner->link<>''): ?>
            <a href="<?php echo e($banner->link); ?>" target="_blank"><img src="uploads/banners/<?php echo e($banner->img); ?>" alt="<?php echo e($banner->title); ?>"></a>
        <?php else: ?>
            <img src="uploads/banners/<?php echo e($banner->img); ?>" alt="<?php echo e($banner->title); ?>">
        <?php endif; ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<h1 class="h1_home">tienda ananké</h1>
<div class="espaciado">
    <section class="productos">
        <h2 class="centrado_m_1">productos mas vendidos</h2>
        <div class="contenedor">
        <?php $__currentLoopData = $productos_mas_vendidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('partials._card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <p class="centrado_m_1">
            <a href="<?php echo e(route('productos')); ?>" class="botones">ver mas productos</a>
        </p>
    </section>
    <br>
    <section class="categotias">
        <h2 class="centrado_m_1">categorías</h2>
        <div class="contenedor">
        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <article onclick="document.location='<?php echo e(route('categoria', $categoria->slug)); ?>'">
                <div style="background-image: url(uploads/categorias/<?php echo e($categoria->foto); ?>);"></div>
                <a href="<?php echo e(route('categoria', $categoria->slug)); ?>"><?php echo e($categoria->nombre); ?></a>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
    <section class="productos">
        <h2 class="centrado_m_1">productos destacados</h2>
        <div class="contenedor">
        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('partials._card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <p class="centrado_m_1">
            <a href="<?php echo e(route('productos')); ?>" class="botones">ver mas productos</a>
        </p>
    </section>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
    <script>
    <?php if($banners->count()>1): ?>
        var t;
        var act=0;
        const tot=<?php echo e($banners->count()); ?>;
        mostrar_banner=function(){
            clearTimeout(t);
            if(act != 0){
                $('.banners_home2 .item:nth-child(' + act + ')').fadeOut(500);
            }
            act++;
            if(act>tot) act=1;
            setTimeout(function(){
                $('.banners_home2 .item:nth-child(' + act + ')').fadeIn(500);
            },500);
            t=setTimeout(mostrar_banner, 5000);
        }
        $(window).load(function(){
            mostrar_banner();
        })
    <?php else: ?>
        $(window).load(function(){
            $('.banners_home2 .item').fadeIn(500);
        });
    <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\tienda_ananke\resources\views/home.blade.php ENDPATH**/ ?>