<section class="cu-hero">
    <div class="cu-container">
        <div class="cu-hero__content">
            <div class="cu-hero__content__left">
                <h2>Compra el vehículo que deseas al mejor precio.</h2>
                <h3>Con la confianza, seguridad y certificación que solo nosotros podemos ofrecerte</h3>
                <a class="cu-button cu-button--filled" aria-controls="cu-search-bar" aria-expanded="false">Buscar</a>
                <p>Descubre todas las opciones que tenemos para ti con solo un click.</p>
            </div>
            <img class="cu-hero__content__image" src="img/content/carros-usados-hero.png" alt="Compra el vehículo que deseas al mejor precio." />
        </div>
    </div>
</section><?php /**PATH D:\wamp64\www\carros_usados\resources\views/partials/_hero.blade.php ENDPATH**/ ?>