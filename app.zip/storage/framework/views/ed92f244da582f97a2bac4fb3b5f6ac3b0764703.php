

<?php $__env->startSection('content'); ?>
<div class="internas">
    <h1>Compra exitosa</h1>
    <div class="cabra">
        <p>Se ha procesado su pedido exitosamente.</p>
        <p>Te atenderemos gustosamente de Lunes a Viernes de 9:00am – 4:00pm.<br>Pronto serás contactado por nuestro equipo de ventas.</p>
        <p>Puedes hacer seguimiento de <a href="<?php echo e(route('mis_compras')); ?>">tus pedidos….</a></p>
        <img src="img/home.jpg" alt="Tienda ananké">
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\tienda_ananke\resources\views/compra_exitosa.blade.php ENDPATH**/ ?>