<header class="cu-header">
    <div class="cu-header__main">
        <h1 class="cu-header__main__brand"><a href="<?php echo e(route('home')); ?>">Carros Usados</a></h1>
        <button class="cu-button cu-header__search" aria-controls="cu-search-bar" aria-expanded="false">Buscar</button>
    </div>
    <div class="cu-header__bar">
        <h3 class="cu-header__bar__brand"><a href="<?php echo e(route('home')); ?>">Carros Usados</a></h3>
        <button class="cu-button cu-header__search" aria-controls="cu-search-bar" aria-expanded="false">Buscar</button>
    </div>
    <div id="cu-search-bar" class="cu-header__search-bar" aria-hidden="true">
        <?php echo $__env->make('partials._search_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</header>
<main class="cu-main">
<?php /**PATH D:\wamp64\www\carros_usados\resources\views/partials/_header.blade.php ENDPATH**/ ?>