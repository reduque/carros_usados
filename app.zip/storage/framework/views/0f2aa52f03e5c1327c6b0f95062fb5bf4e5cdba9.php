

<?php $__env->startSection('content'); ?>
<div class="internas">
    <h1>Procesar compra</h1>
    <div class="espaciado">
        <form action="<?php echo e(route('shop')); ?>" method="POST">
            <?php echo e(csrf_field()); ?>

            <section class="checkout">
                <div>
                    <h3>Tipo de entrega</h3>
                    <div>
                        <label><input name="tipo_entrega" type="radio" value="Delivery" <?php if(old('tipo_entrega')=='Delivery'): ?> checked <?php endif; ?> required> Delivery</label>
                        <label><input name="tipo_entrega" type="radio" value="Pickup" <?php if(old('tipo_entrega')=='Pickup'): ?> checked <?php endif; ?> > Pickup</label>
                    </div>
                </div>
                <div>
                    <h3>Forma de pago</h3>
                    <div>
                        <label><input name="forma_pago" type="radio" value="Efectivo" <?php if(old('forma_pago')=='Efectivo'): ?> checked <?php endif; ?> required> Efectivo</label>
                        <label><input name="forma_pago" type="radio" value="Transferencia o Pago Móvil" <?php if(old('forma_pago')=='Transferencia o Pago Móvil'): ?> checked <?php endif; ?> > Transferencia o Pago Móvil</label>
                    </div>
                    <div class="tapa"></div>
                </div>
                <div class="teme">
                    <h3>¿Tiene el monto exacto?</h3>
                    <div>
                        <label><input name="monto_exacto" type="radio" value="1" <?php if(old('monto_exacto')=='1'): ?> checked <?php endif; ?> > Si</label>
                        <label><input name="monto_exacto" type="radio" value="0" <?php if(old('monto_exacto')=='0'): ?> checked <?php endif; ?> > No</label>
                        <div class="separadorv"></div>
                        <input type="number" name="monto" min="0" step="0.01" value="<?php echo e(old('monto')); ?>" placeholder="Monto que va a pagar">
                    </div>
                    <div class="tapa"></div>
                </div>
                <div>
                    <h3>Resumen de compra</h3>
                    <p>
                        <table width="100%">
                            <tr class="con_delivery">
                                <th>Sub total</th>
                                <td class="derecha">$ <?php echo e(number_format(session("c_product_subtotal"),2,",",".")); ?></td>
                            </tr>
                            <tr class="con_delivery">
                                <th>Delivery</th>
                                <td class="derecha">$ <?php echo e(number_format(session("c_product_delivery"),2,",",".")); ?></td>
                            </tr>
                            <tr class="con_delivery">
                                <th>Total</th>
                                <td class="derecha">$ <?php echo e(number_format(session("c_product_total"),2,",",".")); ?></td>
                            </tr>
                            <tr class="sin_delivery">
                                <th>Total</th>
                                <td class="derecha">$ <?php echo e(number_format(session("c_product_subtotal"),2,",",".")); ?></td>
                            </tr>
                        </table>
                    </p>
                    <p>El delivery será exonerado a partir de compras de $20</p>
                    <div class="tapa"></div>
                </div>
                <div class="info_entrega">
                    <h3>Información de entrega</h3>
                    <select name="zona_id">
                    <?php $__currentLoopData = $zonas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($zona->id); ?>" <?php if(old('zona_id')==$zona->id): ?> selected <?php endif; ?> ><?php echo e($zona->zona_completa); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <div class="separadorv"></div>
                    <textarea name="direccion" placeholder="Dirección específica / punto de referencia / requerimientos especiales" <?php if($errors->has('direccion')): ?> style="border: 1px solid red" <?php endif; ?> ><?php echo e(old('direccion')); ?></textarea>
                    <div class="separadorv"></div>
                    <input type="text" name="nombre_receptor" maxlength="100" value="<?php echo e(old('nombre_receptor')); ?>" placeholder="Nombre de quien recibe">
                    <div class="separadorv"></div>
                    <input type="text" name="telefono_receptor" maxlength="100" value="<?php echo e(old('telefono_receptor')); ?>" placeholder="Teléfono de quien recibe">
                    <div class="separadorv"></div>
                    <div class="tapa"></div>
                </div>
                <div>
                    <h3>Información de pago</h3>
                    <p>Para pagar en bolívares, completa y envía tu orden. En breve nos comunicaremos contigo para hacerte llegar la cotización y los datos para el pago</p>
                    <p class="peque">
                        <br>
                        <a href="tel:+584125779940"><i class="fas fa-phone-alt"></i>0412-5779940</a> <br>
                        <a href="mailto:tienda@ananke.com.ve"><i class="fas fa-envelope"></i>tienda@ananke.com.ve</a>
                    </p>
                </div>
            </section>
            <br>
            <div class="centrar">
                <a href="<?php echo e(route('shopping_cart')); ?>" class="botones"><i class="fas fa-arrow-left"></i>Regresar al carrito</a>
                <button><i class="fas fa-check"></i>Procesar compra</button>
            </div>
            
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
    <script>
        $(document).ready(function(){
            $('textarea[name="direccion"]').blur(function(){
                $(this).val(($(this).val()).trim());
            })
            function valida_campos(){
                //alert($('input[name="tipo_entrega"]:checked').val());
                if($('input[name="tipo_entrega"]:checked').val()=='Delivery'){
                    $('.con_delivery').show(0);
                    $('.sin_delivery').hide(0);
                    $('.info_entrega .tapa').hide(0);
                    $('textarea[name="direccion"]').prop('required',true);
                    $('textarea[name="direccion"]').attr('minlength',10);
                }else{
                    $('.con_delivery').hide(0);
                    $('.sin_delivery').show(0);
                    $('.info_entrega .tapa').show(0);
                    $('textarea[name="direccion"]').prop('required',false);
                    $('textarea[name="direccion"]').attr('minlength',0);
                }
                el=$('input[name="forma_pago"]:checked');
                if(el.val()=='Efectivo'){
                    $('.teme .tapa').hide(0);
                }else{
                    $('.teme .tapa').show(0);
                }
                el=$('input[name="monto_exacto"]:checked');
                if(el.val()=='1'){
                    $('input[name="monto"]').hide(0);
                }else{
                    $('input[name="monto"]').show(0);
                }
            };
            $('input[name="tipo_entrega"]').change(function(){
                valida_campos();
            })
            $('input[name="forma_pago"]').change(function(){
                valida_campos();
            })
            $('input[name="monto_exacto"]').change(function(){
                valida_campos();
            })
            valida_campos();
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\tienda_ananke\resources\views/checkout.blade.php ENDPATH**/ ?>