

<?php $__env->startSection('content'); ?>
<div class="internas">
    <h1 class="alert">Algo salió mal</h1>
    <div class="cabra">
        <img src="img/home.jpg" alt="Tienda ananké">
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\tienda_ananke\resources\views/fallo.blade.php ENDPATH**/ ?>