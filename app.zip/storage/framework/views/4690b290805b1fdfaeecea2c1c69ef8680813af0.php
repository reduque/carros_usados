

<?php $__env->startSection('content'); ?>
<div class="internas">
    <h1>Carrito de compras</h1>
    <div class="espaciado">
        <?php if(session('c_n_p')==0): ?>
            <h3>No tiene productos en el carrito de compras</h3>
            <br>
            <p><a href="<?php echo e(route('productos')); ?>" class="botones">Ver nuestros productos</a></p>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>Producto</th>
                        <th class="centrar">Cantidad</th>
                        <th class="centrar">Total</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php for($i = 1; $i <= session('c_n_p'); $i++): ?>
                        <tr>
                            <td><?php echo e(session("c_product_name" . ($i))); ?></td>
                            <td class="centrar"><?php echo e(session("c_product_quantity" . ($i))); ?></td>
                            <td class="centrar">$ <?php echo e(number_format(session("c_product_price" . ($i)),2,",",".")); ?></td>
                            <td class="acciones">
                                <a href="<?php echo e(route('producto', session("c_product_slug" . ($i)) )); ?>"><i class="fas fa-pencil-alt"></i></a>
                                <a href="<?php echo e(route('delete_to_cart_p', $i)); ?>" class="eliminar"><i class="far fa-trash-alt"></i></a>
                            </td>
                        </tr>
                    <?php endfor; ?>
                    <tr>
                        <td class="derecha" colspan="2"><b>Total</b></td>
                        <td class="centrar" style="white-space: nowrap"><b>$ <?php echo e(number_format(session("c_product_subtotal"),2,",",".")); ?></b></td>
                        <td> </td>
                    </tr>
                </tbody>
            </table>
            <br>
            <p class="derecha">
                <a href="<?php echo e(route('productos')); ?>" class="botones"><i class="fas fa-eye"></i>Ver más productos</a>
                <a href="<?php echo e(route('checkout')); ?>" class="botones"><i class="fas fa-check"></i>Generar pedido</a>
            </p>
            <p class="amarillo">
                <br>
                Algunos de nuestros productos tienen precios variables ya que dependen de su peso, es por ello que los precios mostrados son referenciales. Al enviar el pedido será contactado por nuetro equipo de ventas donde se concretará el monto final a cancelar y el proceso de pago.
            </p>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\charcuteria_tovar\resources\views/shopping_cart.blade.php ENDPATH**/ ?>