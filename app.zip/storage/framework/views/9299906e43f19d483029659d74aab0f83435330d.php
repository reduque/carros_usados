

<?php $__env->startSection('css'); ?>
    <style>
        table thead, table tbody{
            /*
            display: none;
            */
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
     <div class="col-lg-6">
        <h1 class="page-header">Actualizar productos</h1>
    </div>
    <div class="col-lg-12">
        <ol class="breadcrumb">
            <li><a href="<?php echo e(route('administracion_home')); ?>"><i class="fa fa-dashboard"></i> <?php echo app('translator')->get('administracion.inicio'); ?></a></li>
            <li class="active"><i class="fa fa-fw fa-copy"></i> Actualizar productos</li>
        </ol>
    </div>
</div>
<?php if($ver_formulario): ?>
<form role="form" action="<?php echo e(route('actualizar_productos_procesar')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-lg-4">
            <div class="form-group">
                <label>Archivo</label>
                <input type="file" name="fileUpload" accept=".csv" class="form-control">
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <button type="submit" class="btn btn-success"><i class="fa fa-fw fa-cogs"></i> Procesar</button>  
        </div>
    </div>
</form>
<?php else: ?>
<div class="row">
    <div class="col-lg-12">
        <p class="text-right"><a href="<?php echo e(route('actualizar_productos')); ?>" class="btn btn-sm btn-primary"><i class="fa fa-fw fa-undo"></i> Volver</a></p>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="alert alert-success">Su información se ha procesado correctamente</div>
    </div>
</div>

<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\tienda_ananke\resources\views/administracion/reportes/actualizar_productos.blade.php ENDPATH**/ ?>