<?php for($i = 1; $i <=4; $i++): ?>
    <article>
        <a href="">
            <div>
                <img src="uploads/productos/p<?php echo e(rand(1,11)); ?>.png" alt="ojo tit">
            </div>
            <div>
                <h3>Salsicha cocida Freankfurt superior</h3>
            </div>
        </a>
    </article>
<?php endfor; ?>
<?php /**PATH D:\wamp64\www\charcuteria_tovar\resources\views/partials/_phome.blade.php ENDPATH**/ ?>