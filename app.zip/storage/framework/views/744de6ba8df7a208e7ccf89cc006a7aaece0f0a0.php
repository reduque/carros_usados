

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="cu-category">
    <div class="cu-container cu-container--category">
        <div class="cu-category__header">
            <div class="cu-category__header__left">
                <h4>Ordenar por</h4>
                <div class="cu-select">
                    <select name="ordenamiento" class="ordenamiento">
                        <option value="recientes" <?php if(session('ordenamiento')=='recientes'): ?> selected <?php endif; ?> >Recientes</option>
                        <option value="precio" <?php if(session('ordenamiento')=='precio'): ?> selected <?php endif; ?> >Precio</option>
                    </select>
                </div>
            </div>
            <div class="cu-category__header__search">
                <?php echo $__env->make('partials._search_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <p class="cu-category__header__counter">Mostrando <span><?php echo e($carros->firstItem() . ' - ' . $carros->lastItem()); ?></span> de <span><?php echo e($carros->total()); ?></span></p>
        </div>
        <div class="cu-category__content">
            <div class="cu-category__content__grid">
            <?php $__currentLoopData = $carros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carro_p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('partials._car_card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div>
                <?php echo e($carros->withQueryString()->links()); ?>

            </div>
            
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php
    $url=route('category');
    $u='?';
    foreach(request()->except('page','ordenamiento') as $key => $item){
        $url .= $u . $key . '=' . $item;
        $u='&';
    }
?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<script>
    $(document).ready(function(){
        $('.ordenamiento').change(function(){
            document.location='<?php echo $url . $u; ?>ordenamiento=' + $(this).val();
        })
    })
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\carros_usados\resources\views/category.blade.php ENDPATH**/ ?>