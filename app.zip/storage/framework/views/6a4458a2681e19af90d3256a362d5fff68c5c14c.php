<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <title><?php if(View::hasSection('title')): ?> <?php echo $__env->yieldContent('title'); ?> <?php else: ?> <?php echo e(config('app.name', 'Laravel')); ?> <?php endif; ?> </title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <base href="<?php echo e(asset('/')); ?>">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="manifest" href="<?php echo e(asset("/favicon/site.webmanifest")); ?>">

    <link href="<?php echo e(asset('/') . mix('css/front.css')); ?>" rel="stylesheet">

    <?php echo $__env->yieldContent('css'); ?>
</head>

<body>
    <?php echo $__env->make('partials._header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('partials._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="<?php echo e(asset('/') . mix('js/front.js')); ?>" type="text/javascript"></script>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html><?php /**PATH D:\wamp64\www\carros_usados\resources\views/layouts/front.blade.php ENDPATH**/ ?>