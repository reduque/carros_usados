<form method="GET" action="<?php echo e(route('category')); ?>" class="cu-search-form">
    <input type="search" placeholder="Buscar" name="q" value="<?php echo e(request()->has('q') ? request()->get('q') : ''); ?>" />
    <button type="submit" class="cu-button">Buscar</button>
</form><?php /**PATH D:\wamp64\www\carros_usados\resources\views/partials/_search_form.blade.php ENDPATH**/ ?>