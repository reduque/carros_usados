

<?php $__env->startSection('content'); ?>
<div class="internas">
    <h1><?php echo e($producto->nombre); ?></h1>
    <div class="espaciado">
        <section class="producto">
            <div class="fotos">
                <img id="imgppal" src="uploads/productos/<?php echo e($producto->foto1); ?>" alt="<?php echo e($producto->nombre); ?>">
                <div class="thums">
                <?php for($i = 1; $i <= 4; $i++): ?>
                    <?php if($producto->{'foto' . $i}<>''): ?>
                        <img src="uploads/productos/<?php echo e($producto->{'foto' . $i}); ?>" alt="<?php echo e($producto->nombre); ?>">
                    <?php endif; ?>
                <?php endfor; ?>
                </div>
            </div>
            <div>
                <h3><?php echo e($producto->nombre); ?></h3>
                <p><?php echo nl2br(e($producto->descripcion)); ?></p>
                <?php if($producto->activo and $producto->inventario>0): ?>
                    <?php if($producto->precio<$producto->precio_base): ?>
                        <p class="oferta">Precio completo: <span>$ <?php echo e(number_format($producto->precio_base,2,",",".")); ?></span></p>
                    <?php endif; ?>
                    <p class="marron"><b>Precio:</b> $ <?php echo e(number_format($producto->precio,2,",",".")); ?></p>
                    <p>
                        <form action="<?php echo e(route('add_to_cart_p')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input name="product_id" type="hidden" value="<?php echo e(codifica($producto->id)); ?>">
                            <table>
                                <tr>
                                    <td>
                                        <select name="quantity">
                                            <?php
                                                $tot=($producto->inventario > $producto->venta_maxima) ? $producto->venta_maxima : $producto->inventario;
                                            ?>
                                            <?php for($i = 1; $i <= $tot; $i++): ?>
                                                <option value="<?php echo e($i); ?>" <?php if($i == $q_act): ?> selected <?php endif; ?>><?php echo e($i); ?></option>
                                            <?php endfor; ?>
                                        </select>
                                    </td>
                                    <td><button>Agregar al carrito</button></td>
                                </tr>
                            </table>
                        </form>
                    </p>
                <?php endif; ?>
            </div>
        </section>
        <?php if($productos->count()>0): ?>
        <hr>
            <section class="productos">
                <h2 class="centrado_m_1">productos relacionados</h2>
                <div class="contenedor">
                <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('partials._card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <p class="centrado_m_1">
                    <a href="<?php echo e(route('productos')); ?>" class="botones">ver mas productos</a>
                </p>
            </section>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
<script>
    $(document).ready(function(){
        var t;
        $('.thums img').click(function(){
            $('#imgppal').attr('src', $(this).attr('src'));
            img_act=($(this).index()) + 1;
        })
        var img_act=1;
        var tot_img=$('.thums img').length;
        //alert(tot_img);
        moverfoto=function(){
            img_act++;
            if(img_act>tot_img) img_act=1;
            $('#imgppal').attr('src', $('.thums img:nth-child(' + img_act + ')').attr('src'));
            t=setTimeout(function(){
                moverfoto();
            },2000);
        }
        $('#imgppal').mouseenter(function(){
            clearTimeout(t);
            if(tot_img>1){
                t=setTimeout(function(){
                    moverfoto();
                },300);
            }
        }).mouseleave(function(){
            clearTimeout(t);
        });

    })
</script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\tienda_ananke\resources\views/producto.blade.php ENDPATH**/ ?>