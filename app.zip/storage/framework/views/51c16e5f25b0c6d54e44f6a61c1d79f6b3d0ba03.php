

<?php $__env->startSection('content'); ?>
<div class="internas">
    <h1>Compra exitosa</h1>
    <div class="cabra">
        <p>Se ha procesado su pedido exitosamente.</p>
        <p>Te atenderemos gustosamente de Lunes a Viernes de 9:00am – 5:00pm.</p>
        <p>Pronto serás contactado por nuestro equipo de ventas.</p>
        <p><a href="<?php echo e(route('productos')); ?>" class="amarillo">Seguir comprando</a></p>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\charcuteria_tovar\resources\views/compra_exitosa.blade.php ENDPATH**/ ?>