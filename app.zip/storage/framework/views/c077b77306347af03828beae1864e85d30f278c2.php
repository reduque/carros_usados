<table width="100%" cellpadding="10">
    <tr>
        <td align="center">
			<table cellpadding="10" cellspacing="0" width="600" border="1" bordercolor="#BF965C">
				<thead>
					<tr>
						<th>
							<img src="<?php echo e(asset('img/logo.jpg')); ?>" alt="tienda ananké" width="150">
						</th>
					</tr>
				</thead>
				<tr>
					<td align="center">
						<br><br>
						<p style="font-family: sans-serif"><?php echo e($mensaje); ?></p>
						<br><br>
					</td>
				</tr>
			</table>
		</td>
    </tr>
</table><?php /**PATH D:\wamp64\www\tienda_ananke\resources\views/emails/notificacion.blade.php ENDPATH**/ ?>