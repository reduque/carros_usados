<div class="cu-modal">
    <div class="cu-modal__container">
        <button class="cu-button cu-modal__close">Cerrar</button>
        <?php echo $__env->make('partials._puntos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div><?php /**PATH D:\wamp64\www\carros_usados\resources\views/partials/_modal.blade.php ENDPATH**/ ?>