

<?php $__env->startSection('content'); ?>
<hr>
<div class="cuerpo">
    <h1 class="h2home"><?php echo e($producto->nombre); ?></h1>
    <div class="espaciado">
        <section class="producto">
            <div class="fotos">
                <?php
                    $foto = $producto->foto1 <> '' ? "uploads/productos/" . $producto->foto1 : "img/sinfoto.jpg";
                ?>
                <img id="imgppal" src="<?php echo e($foto); ?>" alt="<?php echo e($producto->nombre); ?>">
                <div class="thums">
                <?php for($i = 1; $i <= 4; $i++): ?>
                    <?php if($producto->{'foto' . $i}<>''): ?>
                        <img src="uploads/productos/<?php echo e($producto->{'foto' . $i}); ?>" alt="<?php echo e($producto->nombre); ?>">
                    <?php endif; ?>
                <?php endfor; ?>
                </div>
            </div>
            <div>
                <h3><?php echo e($producto->nombre); ?></h3>
                <p><?php echo nl2br(e($producto->descripcion)); ?></p>
                <?php if($producto->activo): ?>
                    <?php if($producto->precio<$producto->precio_base): ?>
                        <p class="oferta">Precio completo: <span>$ <?php echo e(number_format($producto->precio_base,2,",",".")); ?></span></p>
                    <?php endif; ?>
                    <p class="marron"><b>Precio:</b> $ <?php echo e(number_format($producto->precio,2,",",".")); ?>

                    <?php if($producto->tipo == 'Por gramos'): ?>
                        <br><span class="amarillo">por KG, <?php echo e($producto->gramos); ?></span>
                    <?php endif; ?>
        
                    </p>
                    <p>
                        <form action="<?php echo e(route('add_to_cart_p')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input name="product_id" type="hidden" value="<?php echo e(codifica($producto->id)); ?>">
                            <div class="form_p">
                                <select name="quantity">
                                    <?php
                                        $tot=10;
                                    ?>
                                    <?php for($i = 1; $i <= $tot; $i++): ?>
                                        <option value="<?php echo e($i); ?>" <?php if($i == $q_act): ?> selected <?php endif; ?>><?php echo e($i); ?></option>
                                    <?php endfor; ?>
                                </select>
                                <button>Agregar al carrito el producto</button>
                            </div>
                        </form>
                    </p>
                <?php endif; ?>
            </div>
        </section>
    <?php if($productos->count()>0): ?>
        <hr>
        <h2 class="h2home">productos relacionados</h2>
        <section class="productos_grid">
            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('partials._card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </section>
        <a href="<?php echo e(route('productos')); ?>" class="amarillo">ver mas productos</a>
        </section>
    <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
<script>
    $(document).ready(function(){
        var t;
        $('.thums img').click(function(){
            $('#imgppal').attr('src', $(this).attr('src'));
            img_act=($(this).index()) + 1;
        })
        var img_act=1;
        var tot_img=$('.thums img').length;
        //alert(tot_img);
        moverfoto=function(){
            img_act++;
            if(img_act>tot_img) img_act=1;
            $('#imgppal').attr('src', $('.thums img:nth-child(' + img_act + ')').attr('src'));
            t=setTimeout(function(){
                moverfoto();
            },2000);
        }
        $('#imgppal').mouseenter(function(){
            clearTimeout(t);
            if(tot_img>1){
                t=setTimeout(function(){
                    moverfoto();
                },300);
            }
        }).mouseleave(function(){
            clearTimeout(t);
        });

    })
</script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\charcuteria_tovar\resources\views/producto.blade.php ENDPATH**/ ?>