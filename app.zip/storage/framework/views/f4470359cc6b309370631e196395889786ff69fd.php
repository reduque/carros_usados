

<?php $__env->startSection('content'); ?>

<div class="row">
     <div class="col-lg-6">
        <h1 class="page-header">Productos</h1>
    </div>
    <div class="col-lg-12">
        <ol class="breadcrumb">
            <li><a href="<?php echo e(route('administracion_home')); ?>"><i class="fa fa-dashboard"></i> <?php echo app('translator')->get('administracion.inicio'); ?></a></li>
            <li><a href="<?php echo e(route('categories.edit', codifica($category->id))); ?>"><i class="fa fa-fw fa-pencil"></i> <?php echo e($category->nombre); ?></a></li>
            <li class="active"><i class="fa fa-fw fa-pencil"></i> <?php echo app('translator')->get('administracion.products'); ?></li>
        </ol>
    </div>
</div>
<div class="row">
    <div class="col-lg-8">
    <?php if($notificacion_error=Session::get('notificacion_error')): ?>
        <div class="alert alert-danger"><?php echo e($notificacion_error); ?></div>
    <?php endif; ?>
    </div>
    <div class="col-lg-4">
        <p class="text-right"><a href="<?php echo e(route('productos.create')); ?>" class="btn btn-sm btn-primary"><i class="fa fa-fw fa-plus-circle"></i> <?php echo app('translator')->get('administracion.nuevo'); ?></a></p>
    </div>
</div>

<div class="row">
    <div class="col-lg-12"><!-- class tr active success warning danger -->
        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th width="60"></th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr data-id='<?php echo e(codifica($producto->id)); ?>'>
                        <td><a href="<?php echo e(route('productos.edit', codifica($producto->id) )); ?>" title="<?php echo app('translator')->get('administracion.editar'); ?>"><?php echo e($producto->nombre); ?></a></td>
                        <td>
                            <a href="<?php echo e(route('productos.edit', codifica($producto->id) )); ?>" title="<?php echo app('translator')->get('administracion.editar'); ?>"><i class="fa fa-fw fa-edit"></i></a>
                            <a href="<?php echo e(route('productos_eliminar', codifica($producto->id) )); ?>" title="<?php echo app('translator')->get('administracion.eliminar'); ?>"><i class="fa fa-fw fa-ban bloquear"></i></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<!--
<div class="row">
    <div class="col-lg-12">
        $productos->appends(Request::except('page'))->render()
    </div>
</div>
-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script type="text/javascript">
$(document).ready(function(){
    $(".bloquear").click(function(event){
        event.preventDefault();
        if(confirm("<?php echo app('translator')->get('administracion.confirmar_eliminar'); ?>")){
            document.location=$(this).parent().attr("href");
        }
    })
    setTimeout(function(){
        $(".alert").slideUp(500);
    },10000)
    $('tbody').sortable({
        stop: function( event, ui ) {
            ids=new Array();
            $('tbody tr').each(function(){
                ids.push($(this).data('id'));
            });
            $.ajax({
                'url' : "<?php echo e(route('ordena_productos')); ?>?ids=" + ids
            });
        }
    });
})
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\tienda_ananke\resources\views/administracion/productos/index.blade.php ENDPATH**/ ?>