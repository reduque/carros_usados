

<?php $__env->startSection('css'); ?>
    <link href="css/slim.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
     <div class="col-lg-6">
        <h1 class="page-header"><?php echo app('translator')->get('administracion.products'); ?></h1>
    </div>
    <div class="col-lg-12">
        <ol class="breadcrumb">
            <li><a href="<?php echo e(route('administracion_home')); ?>"><i class="fa fa-dashboard"></i> <?php echo app('translator')->get('administracion.inicio'); ?></a></li>
            <li><a href="<?php echo e(route('categories.edit', codifica($category->id))); ?>"><i class="fa fa-fw fa-pencil"></i> <?php echo e($category->nombre); ?></a></li>
            <li><a href="<?php echo e(route("productos.index")); ?>"><i class="fa fa-fw fa-pencil"></i> <?php echo app('translator')->get('administracion.products'); ?></a></li>
            <li><?php echo app('translator')->get('administracion.crear'); ?></li>
        </ol>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <p class="text-right"><a href="<?php echo e(route('productos.index')); ?>" class="btn btn-sm btn-primary"><i class="fa fa-fw fa-list"></i> <?php echo app('translator')->get('administracion.volver_lista'); ?></a></p>
    </div>
</div>

<form role="form" action="<?php echo e(route('productos.store')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

    <input type="hidden" name="category_id" value="<?php echo e($category->id); ?>">
    <div class="row">
        <div class="col-lg-4">
            <div class="form-group">
                <label>Código ananké</label>
                <input type="text" class="form-control" name="idananke" value="<?php echo e(old('idananke')); ?>" maxlength="50">
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-6">
            <div class="form-group<?php echo e($errors->has('nombre') ? ' has-error' : ''); ?>">
                <label>Nombre</label>
                <input type="text" class="form-control" name="nombre" value="<?php echo e(old('nombre')); ?>" maxlength="100" required autofocus>
                <?php if($errors->has('nombre')): ?>
                    <p class="help-block"><?php echo e($errors->first('nombre')); ?></p>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="form-group<?php echo e($errors->has('precio_base') ? ' has-error' : ''); ?>">
                <label>Precio base en $</label>
                <input type="number" step="0.01" min="0" class="form-control" name="precio_base" value="<?php echo e(old('precio_base')); ?>" required>
                <?php if($errors->has('precio_base')): ?>
                    <p class="help-block"><?php echo e($errors->first('precio_base')); ?></p>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="form-group<?php echo e($errors->has('precio') ? ' has-error' : ''); ?>">
                <label>Precio final en $</label>
                <input type="number" step="0.01" min="0" class="form-control" name="precio" value="<?php echo e(old('precio')); ?>" required>
                <?php if($errors->has('precio')): ?>
                    <p class="help-block"><?php echo e($errors->first('precio')); ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-4">
            <div class="form-group<?php echo e($errors->has('venta_maxima') ? ' has-error' : ''); ?>">
                <label>Venta maxima</label>
                <input type="number" step="0.01" min="0" class="form-control" name="venta_maxima" value="<?php echo e(old('venta_maxima')); ?>" required>
                <?php if($errors->has('venta_maxima')): ?>
                    <p class="help-block"><?php echo e($errors->first('venta_maxima')); ?></p>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="form-group<?php echo e($errors->has('inventario') ? ' has-error' : ''); ?>">
                <label>Inventario</label>
                <input type="number" step="1" min="0" class="form-control" name="inventario" value="<?php echo e(old('inventario')); ?>" required>
                <?php if($errors->has('inventario')): ?>
                    <p class="help-block"><?php echo e($errors->first('inventario')); ?></p>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-lg-2">
            <div class="form-group">
                <br>
                <input type="checkbox" class="" name="activo" id="activo" value="1" <?php if( old('activo',1) == 1 ): ?> checked <?php endif; ?> >&nbsp;&nbsp;<label for="activo">Activo</label>
            </div>
        </div>
        <div class="col-lg-2">
            <div class="form-group">
                <br>
                <input type="checkbox" class="" name="destacado" id="destacado" value="1" <?php if( old('destacado',1) == 1 ): ?> checked <?php endif; ?> >&nbsp;&nbsp;<label for="destacado">Destacado</label>
            </div>
        </div>        
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="form-group">
                <label>Descripción</label>
                <textarea class="form-control" rows="5" name="descripcion"><?php echo e(old('descripcion')); ?></textarea>
            </div>
        </div>
    </div>
    <div class="row">
        <?php for($i = 1; $i <= 4; $i++): ?>
        <div class="col-lg-3">
            <div class="form-group">
                <label>Imagen <?php echo e($i); ?></label>
                <div class="slim">
                    <input name="foto<?php echo e($i); ?>" type="file" accept="image/jpeg, image/png" />
                </div>
                <label><span>Tamaño mímino 640 x 640 px | JPG o PNG</span></label>
            </div>
        </div>
        <?php endfor; ?>
    </div>

    <h3>Metadata</h3>
    <div class="row">
        <div class="col-lg-6">
            <div class="form-group">
                <label>Title</label>
                <input type="text" class="form-control" name="meta_title" value="<?php echo e(old('meta_title')); ?>" maxlength="200">
            </div>
        </div>
        <div class="col-lg-6">
            <div class="form-group">
                <label>Keywords</label>
                <input type="text" class="form-control" name="meta_keywords" value="<?php echo e(old('meta_keywords')); ?>" maxlength="200">
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="form-group">
                <label>Description</label>
                <input type="text" class="form-control" name="meta_description" value="<?php echo e(old('meta_description')); ?>" maxlength="200">
            </div>
        </div>
    </div>
    
    <div class="row">
        <div class="col-lg-12">
            <button type="submit" class="btn btn-success"><i class="fa fa-fw fa-check"></i> <?php echo app('translator')->get('administracion.guardar'); ?></button>  
            <a href="<?php echo e(route('productos.index')); ?>" class="btn btn-primary"><i class="fa fa-fw fa-list"></i> <?php echo app('translator')->get('administracion.volver_lista'); ?></a>
        </div>
    </div>
</form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script src="js/slim.jquery.js"></script>
<script type="text/javascript">
  $(document).ready(function(){
   $('.slim').slim({
      label: 'Arrastra tu imagen ó haz click aquí',
      ratio: '1:1',
      forceType: 'jpg',
      minSize: {
        width: 640,
        height: 640
      },
      size: {
        width: 640,
        height: 640
      },
      download: false,
      labelLoading: 'Cargando imagen...',
      statusImageTooSmall: 'La imagen es muy pequeña. El tamaño mínimo es $0 píxeles.',
      statusUnknownResponse: 'Ha ocurrido un error inesperado.',
      statusUploadSuccess: 'Imagen guardada',
      statusFileSize: 'El tamaño máximo de imagen es 1MB.',
      statusFileType: 'El formato de imagen no es permitido. Solamente: $0.',
      buttonConfirmLabel: 'Aceptar',
      buttonConfirmTitle: 'Aceptar',
      buttonCancelLabel: 'Cancelar',
      buttonCancelLabel: "Cancelar",
      buttonCancelTitle: "Cancelar",
      buttonEditTitle: "Editar",
      buttonRemoveTitle: "Eliminar",
      buttonRotateTitle: "Rotar",
      buttonUploadTitle: "Guardar"
    });
 })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\tienda_ananke\resources\views/administracion/productos/create.blade.php ENDPATH**/ ?>