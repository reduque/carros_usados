<section class="cu-related">
    <h3 class="cu-related__title"><span>Vehiculos similares</span></h3>
    <div class="cu-related__grid">
        <?php $__currentLoopData = $relacionados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carro_p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('partials._car_card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section><?php /**PATH D:\wamp64\www\carros_usados\resources\views/partials/_related.blade.php ENDPATH**/ ?>