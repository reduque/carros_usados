<?php
    $tiene_oferta = ($producto->precio<$producto->precio_base);
?>
<article onclick="document.location='<?php echo e(route('producto', $producto->slug)); ?>'">
    <div class="foto" style="background-image: url(uploads/productos/<?php echo e($producto->foto1); ?>);"></div>
    <a href="<?php echo e(route('producto', $producto->slug)); ?>">
        <?php echo e($producto->nombre); ?>

    </a>
    <?php if($tiene_oferta): ?>
        <p class="oferta">$ <?php echo e(number_format($producto->precio_base,2,",",".")); ?></p>
        <div class="oferta"></div>
    <?php endif; ?>
    <p class="precio">$ <?php echo e(number_format($producto->precio,2,",",".")); ?></p>
</article>
<?php /**PATH D:\wamp64\www\tienda_ananke\resources\views/partials/_card.blade.php ENDPATH**/ ?>