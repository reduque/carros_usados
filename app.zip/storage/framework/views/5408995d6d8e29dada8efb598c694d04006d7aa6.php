<table width="100%" cellpadding="10">
    <tr>
        <td align="center">
			<table cellpadding="10" cellspacing="0" width="600" border="1" bordercolor="#ED1B24">
				<thead>
					<tr>
						<th>
							<img src="<?php echo e(asset('img/logo.png')); ?>" alt="Charcutería Tovar" width="100">
						</th>
					</tr>
				</thead>
				<tr>
					<td>
                        <h3>Información del cliente</h3>
                        <b>Nombre:</b> <?php echo e(Auth::user()->name); ?><br>
                        <b>Email:</b> <?php echo e(Auth::user()->email); ?><br>
                        <b>Teléfonos:</b> <?php echo e(Auth::user()->telefonos); ?><br>
                        <b>CI:</b> <?php echo e(Auth::user()->ci); ?><br>
                        <b>Fecha de nacimiento:</b> <?php echo e(Auth::user()->fecha_nacimiento <>'' ? date('d/m/Y',strtotime(Auth::user()->fecha_nacimiento)) : ''); ?>

					</td>
				</tr>
				<tr>
					<td>
                        <h3>Información del pedido</h3>
                        <table cellspacing="0" width="100%" border="1" bordercolor="#ccc">
                            <thead>
                                <tr>
                                    <th>Producto</th>
                                    <th>Cantidad</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php for($i = 1; $i <= session('c_n_p'); $i++): ?>
                                    <tr>
                                        <td><?php echo e(session("c_product_name" . ($i))); ?></td>
                                        <td><?php echo e(session("c_product_quantity" . ($i))); ?></td>
                                        <td>$ <?php echo e(number_format(session("c_product_price" . ($i)),2,",",".")); ?></td>
                                    </tr>
                                <?php endfor; ?>
                                <tr>
                                    <td colspan="2"><b>Total</b></td>
                                    <td style="white-space: nowrap"><b>$ <?php echo e(number_format(session("c_product_subtotal"),2,",",".")); ?></b></td>
                                </tr>
                            </tbody>
            
                        </table>
					</td>
				</tr>
			</table>
		</td>
    </tr>
</table>
<?php /**PATH D:\wamp64\www\charcuteria_tovar\resources\views/emails/orden.blade.php ENDPATH**/ ?>