

<?php $__env->startSection('css'); ?>
    <style>
        table thead, table tbody{
            /*
            display: none;
            */
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
     <div class="col-lg-6">
        <h1 class="page-header">Reporte de compras</h1>
    </div>
    <div class="col-lg-12">
        <ol class="breadcrumb">
            <li><a href="<?php echo e(route('administracion_home')); ?>"><i class="fa fa-dashboard"></i> <?php echo app('translator')->get('administracion.inicio'); ?></a></li>
            <li class="active"><i class="fa fa-fw fa-copy"></i> Reporte de compras</li>
        </ol>
    </div>
</div>
<?php if($ver_formulario): ?>
<form role="form" action="<?php echo e(route('reporte_compras')); ?>" method="GET">
    <div class="row">
        <div class="col-lg-4">
            <div class="form-group">
                <label>Mese</label>
                <select name="mes" class="form-control">
                <?php for($i = 1; $i <= 12; $i++): ?>
                    <option value="<?php echo e($i); ?>"><?php echo e(meses($i)); ?></option>
                <?php endfor; ?>
                </select>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="form-group">
                <label>Año</label>
                <select name="ano" class="form-control">
                <?php for($i = date('Y'); $i >= 2020; $i--): ?>
                    <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                <?php endfor; ?>
                </select>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <button type="submit" class="btn btn-success"><i class="fa fa-fw fa-search"></i> Consultar</button>  
        </div>
    </div>
</form>
<?php else: ?>
<div class="row">
    <div class="col-lg-12">
        <p class="text-right"><a href="javascript:window.history.back(1)" class="btn btn-sm btn-primary"><i class="fa fa-fw fa-undo"></i> Volver al filtro</a></p>
    </div>
</div>

<div class="row">
    <div class="col-lg-12"><!-- class tr active success warning danger -->
        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th>Fecha de la orden</th>
                        <th>email</th>
                        <th>Producto</th>
                        <th>Precio</th>
                        <th>Cantidad</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $ordenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orden): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(date('d/m/Y',strtotime($orden->created_at))); ?></td>
                        <td><?php echo e($orden->email); ?></td>
                        <td><?php echo e($orden->nombre); ?></td>
                        <td>$ <?php echo e(number_format($orden->precio,2,",",".")); ?></td>
                        <td><?php echo e($orden->cantidad); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<?php if(!$ver_formulario): ?>
<script src="https://sistemasdemos.com/gratis/exportar_html_excel/FileSaver.min.js"></script>
<script src="https://sistemasdemos.com/gratis/exportar_html_excel/Blob.min.js"></script>
<script src="https://sistemasdemos.com/gratis/exportar_html_excel/xls.core.min.js"></script>
<script src="https://sistemasdemos.com/gratis/exportar_html_excel/dist/js/tableexport.js"></script>

<script type="text/javascript">
$(document).ready(function(){
    $("table").tableExport({
        formats: ["xlsx"], //Tipo de archivos a exportar ("xlsx","txt", "csv", "xls")
        exportButtons: false,
        position: "top", // Posicion que se muestran los botones puedes ser: (top, bottom)
        bootstrap: false, //Usar lo estilos de css de bootstrap para los botones (true, false)
        fileName: "ReporteCompras_<?php echo e(date('dmYhi')); ?>", //Nombre del archivo 
    });
})
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\tienda_ananke\resources\views/administracion/reportes/reporte_compras.blade.php ENDPATH**/ ?>