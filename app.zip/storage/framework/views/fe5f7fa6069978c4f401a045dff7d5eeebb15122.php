</main>
    <footer class="cu-footer">
      <div class="cu-footer__top">
        <h3>Marcas disponibles</h3>
        <p>Llega rápido al carro que te interesa</p>
        <div class="cu-footer__top__search">
          <?php echo $__env->make('partials._search_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <ul>
        <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><a href="<?php echo e(route('category')); ?>?marca=<?php echo e($marca->marca); ?>"><?php echo e(ucfirst(strtolower($marca->marca))); ?></a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
      <div class="cu-footer__bottom">
        <div class="cu-footer__bottom__copy">
          <h3><a href="">Carros Usados</a></h3>
          <p>Copyright &copy; 2021 Carros Usados. Todos los derechos reservados.</p>
        </div>
        <ul class="cu-footer__bottom__contact">
          <li>
            <a href="tel:2123453256">(0212) 345-3256</a>
          </li>
          <li>
            <a href="mailto:info@carrosusados.com">info@carrosusados.com</a>
          </li>
        </ul>
      </div>
</footer><?php /**PATH D:\wamp64\www\carros_usados\resources\views/partials/_footer.blade.php ENDPATH**/ ?>