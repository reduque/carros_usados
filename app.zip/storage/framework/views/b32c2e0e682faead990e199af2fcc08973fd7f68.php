<div class="cu-points">
    <h3 class="cu-points__title">Certificación de condición técnica</h3>
    <div class="cu-points__wrapper">
        <ul class="cu-points__points">
        <?php
            $grupo='';
        ?>
        <?php $__currentLoopData = $carro->puntos_intermedia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($grupo <> $item->punto->grupo->grupo){ ?>
            <li>
                <h5 align="center"><?php echo e($item->punto->grupo->grupo); ?><span></span></h5>
            </li>
            <?php
                $grupo = $item->punto->grupo->grupo;
            }?>
            <li>
                <h5><span><?php echo e($item->punto->punto); ?></span></h5>
                <div class="<?php echo e(($item->respuesta) ? 'activo' : 'inactivo'); ?>"></div>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div><?php /**PATH D:\wamp64\www\carros_usados\resources\views/partials/_puntos.blade.php ENDPATH**/ ?>