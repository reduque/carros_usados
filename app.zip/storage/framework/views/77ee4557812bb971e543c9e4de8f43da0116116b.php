

<?php $__env->startSection('content'); ?>

<div class="row">
     <div class="col-lg-6">
        <h1 class="page-header">Órdenes</h1>
    </div>
    <div class="col-lg-12">
        <ol class="breadcrumb">
            <li><a href="<?php echo e(route('administracion_home')); ?>"><i class="fa fa-dashboard"></i> <?php echo app('translator')->get('administracion.inicio'); ?></a></li>
            <li><a href="<?php echo e(route('ordenes')); ?>"><i class="fa fa-fw fa-check-square"></i> Órdenes</a></li>
            <li class="active"><i class="fa fa-fw fa-pencil"></i> Detalle</li>
        </ol>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
    <?php if($notificacion=Session::get('notificacion')): ?>
        <div class="alert alert-success"><?php echo e($notificacion); ?></div>
    <?php endif; ?>
    </div>
</div>

<div class="row">
    <div class="col-lg-12"><!-- class tr active success warning danger -->
        <div class="table-responsive">
            <table class="table table-bordered">
                <tr>
                    <td>
                        <b>Fecha de compra: </b> <?php echo e($orden->fecha); ?>

                        <br>
                        <b>Tipo de entrega:</b> <?php echo e($orden->tipo_entrega); ?>

                        <br>
                        <b>Forma de pago: </b> <?php echo e($orden->forma_pago); ?>

                        <?php if($orden->forma_pago=='Efectivo'): ?>
                            <br>
                            <b>Monto exacto: </b> <?php echo e(($orden->monto_exacto == 1) ? 'Si' : 'No'); ?>

                            <?php if($orden->monto_exacto == 0): ?>
                                <br>
                                <b>Monto: </b> $ <?php echo e(number_format($orden->monto,2,",",".")); ?>

                            <?php endif; ?>
                        <?php endif; ?>
                    </td>
                    <td>
                        <b>N. orden:</b> <?php echo e(str_pad($orden->id,5,"0",STR_PAD_LEFT)); ?>

                        <br>
                        <b>Estado: </b> <?php echo e($orden->estado_real); ?>

                    </td>
                </tr>
                <tr>
                    <td>
                        <h4>Cliente</h4>
                        <b>Nombre: </b> <?php echo e($orden->usuario->name); ?>

                        <br>
                        <b>email: </b> <?php echo e($orden->usuario->email); ?>

                        <br>
                        <b>Teléfonos: </b> <?php echo e($orden->usuario->telefonos); ?>

                        <br>
                        <b>CI: </b> <?php echo e($orden->usuario->ci); ?>

                        <br>
                        <b>Fecha de nacimiento: </b> <?php echo e(($orden->usuario->fecha_nacimiento) ? date('d/m/Y', strtotime($orden->usuario->fecha_nacimiento)) : ''); ?>

                    </td>
                    <td>
                        <?php if($orden->tipo_entrega=='Delivery'): ?>
                            <h4>Información de entrega</h4>
                            <b>Zona: </b> <?php echo e($orden->zona->zona_completa); ?>

                            <br>
                            <b>Detalles: </b> <?php echo nl2br(e($orden->direccion)); ?>

                            <br>
                            <b>Nombre: </b> <?php echo e($orden->nombre_receptor); ?>

                            <br>
                            <b>Teléfonos: </b> <?php echo e($orden->telefono_receptor); ?>

    
                        <?php endif; ?>
                    </td>
                </tr>
            </table>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Producto</th>
                        <th>Cantidad</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $orden->productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><a href="<?php echo e(route('producto', $producto->producto->slug )); ?>"><?php echo e($producto->producto->nombre); ?></a></td>
                            <td><?php echo e($producto->cantidad); ?></td>
                            <td align="right">$ <?php echo e(number_format($producto->total,2,",",".")); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td align="right" colspan="2"><b>Subtotal<br>Delivery<br>Total</b></td>
                        <td align="right"><b>$ <?php echo e(number_format( $orden->subtotal ,2,",",".")); ?><br>$ <?php echo e(number_format( $orden->delirery ,2,",",".")); ?><br>$ <?php echo e(number_format( $orden->total ,2,",",".")); ?></b></td>
                    </tr>
                </tbody>
            </table>

        </div>
    </div>
</div>
<div class="row">
    <div class="col-lg-6">
        <?php switch($orden->estado):
            case (0): ?>
                <a href="<?php echo e(route('ordene_actualizar',['id' => codifica($orden->id), 'accion' => 1, 'nuevo_estado' => 'Aprobada'])); ?>" class="btn btn-success"><i class="fa fa-fw fa-check"></i> Aprobar pedido</a>  
                <?php break; ?>
            <?php case (1): ?>
                <a href="<?php echo e(route('ordene_actualizar',['id' => codifica($orden->id), 'accion' => 2, 'nuevo_estado' => 'En preparación para despacho / entrega'])); ?>" class="btn btn-success"><i class="fa fa-fw fa-check"></i> En preparación para despacho / entrega</a>  
                <?php break; ?>
            <?php case (2): ?>
                <a href="<?php echo e(route('ordene_actualizar',['id' => codifica($orden->id), 'accion' => 3, 'nuevo_estado' => 'En despacho / listo para entrega'])); ?>" class="btn btn-success"><i class="fa fa-fw fa-check"></i> En despacho / listo para entrega</a>  
                <?php break; ?>
            <?php case (3): ?>
                <a href="<?php echo e(route('ordene_actualizar',['id' => codifica($orden->id), 'accion' => 4, 'nuevo_estado' => 'Despachado / entregado'])); ?>" class="btn btn-success"><i class="fa fa-fw fa-check"></i> Despachado / entregado</a>  
                <?php break; ?>

        <?php endswitch; ?>
        <a href="<?php echo e(route('ordene_actualizar',['id' => codifica($orden->id), 'accion' => 'eliminar'])); ?>" class="btn btn-danger"><i class="fa fa-fw fa-ban"></i> Eliminar</a>
        <a href="<?php echo e(route('ordenes')); ?>" class="btn btn-primary"><i class="fa fa-fw fa-list"></i> <?php echo app('translator')->get('administracion.volver_lista'); ?></a> 
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script type="text/javascript">
$(document).ready(function(){
    $(".btn-danger").click(function(event){
        event.preventDefault();
        if(confirm("¿Está seguro de eliminar este pedido?")){
            document.location=$(this).attr("href");
        }
    })
    setTimeout(function(){
        $(".alert").slideUp(500);
    },10000)
})
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\tienda_ananke\resources\views/administracion/productos/ordene_detalle.blade.php ENDPATH**/ ?>