<?php
    $tiene_oferta = ($producto->precio<$producto->precio_base);
    $foto = $producto->foto1 <> '' ? "uploads/productos/" . $producto->foto1 : "img/sinfoto.jpg";
?>
<article>
    <a href="<?php echo e(route('producto', $producto->slug)); ?>">
        <div class="img" style="background-image: url(<?php echo e($foto); ?>)"></div>
        <h3><?php echo e($producto->nombre); ?></h3>
        <h4>
            <?php if($tiene_oferta): ?>
                <p class="oferta">$ <?php echo e(number_format($producto->precio_base,2,",",".")); ?></p>
                <div class="oferta">En oferta</div>
            <?php endif; ?>
            $ <?php echo e(number_format($producto->precio,2,",",".")); ?>

            <?php if($producto->tipo == 'Por gramos'): ?>
                <span>por KG</span>
            <?php endif; ?>
        </h4>
    </a>
</article>
<?php /**PATH D:\wamp64\www\charcuteria_tovar\resources\views/partials/_card.blade.php ENDPATH**/ ?>