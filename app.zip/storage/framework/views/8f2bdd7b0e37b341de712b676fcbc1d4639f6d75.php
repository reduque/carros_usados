

<?php $__env->startSection('css'); ?>
    <style>
        table thead, table tbody{
            /*
            display: none;
            */
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
     <div class="col-lg-6">
        <h1 class="page-header">Descargar productos</h1>
    </div>
    <div class="col-lg-12">
        <ol class="breadcrumb">
            <li><a href="<?php echo e(route('administracion_home')); ?>"><i class="fa fa-dashboard"></i> <?php echo app('translator')->get('administracion.inicio'); ?></a></li>
            <li class="active"><i class="fa fa-fw fa-copy"></i> Descargar productos</li>
        </ol>
    </div>
</div>

<div class="row">
    <div class="col-lg-12"><!-- class tr active success warning danger -->
        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th>Id interno</th>
                        <th>Código ananké</th>
                        <th>Nombre</th>
                        <th>Precio base en $</th>
                        <th>Precio final en $</th>
                        <th>Inventario</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($producto->id); ?></td>
                        <td><?php echo e($producto->idananke); ?></td>
                        <td><?php echo e($producto->nombre); ?></td>
                        <td><?php echo e($producto->precio_base); ?></td>
                        <td><?php echo e($producto->precio); ?></td>
                        <td><?php echo e($producto->inventario); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script src="https://sistemasdemos.com/gratis/exportar_html_excel/FileSaver.min.js"></script>
<script src="https://sistemasdemos.com/gratis/exportar_html_excel/Blob.min.js"></script>
<script src="https://sistemasdemos.com/gratis/exportar_html_excel/xls.core.min.js"></script>
<script src="https://sistemasdemos.com/gratis/exportar_html_excel/dist/js/tableexport.js"></script>

<script type="text/javascript">
$(document).ready(function(){
    $("table").tableExport({
        formats: ["xlsx"], //Tipo de archivos a exportar ("xlsx","txt", "csv", "xls")
        exportButtons: false,
        position: "top", // Posicion que se muestran los botones puedes ser: (top, bottom)
        bootstrap: false, //Usar lo estilos de css de bootstrap para los botones (true, false)
        fileName: "ListadoProductos_<?php echo e(date('dmYhi')); ?>", //Nombre del archivo 
    });
})
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\tienda_ananke\resources\views/administracion/reportes/descargar_productos.blade.php ENDPATH**/ ?>