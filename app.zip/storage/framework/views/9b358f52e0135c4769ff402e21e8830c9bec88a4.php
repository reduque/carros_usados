

<?php $__env->startSection('content'); ?>

<div class="row">
     <div class="col-lg-6">
        <h1 class="page-header"><?php echo app('translator')->get('administracion.banners'); ?></h1>
    </div>
    <div class="col-lg-12">
        <ol class="breadcrumb">
            <li><a href="<?php echo e(route('administracion_home')); ?>"><i class="fa fa-dashboard"></i> <?php echo app('translator')->get('administracion.inicio'); ?></a></li>
            <li class="active"><i class="fa fa-fw fa-pencil"></i> <?php echo app('translator')->get('administracion.banners'); ?></li>
        </ol>
    </div>
</div>
<div class="row">
    <div class="col-lg-10">
    <?php if($notificacion_error=Session::get('notificacion_error')): ?>
        <div class="alert alert-danger"><?php echo e($notificacion_error); ?></div>
    <?php endif; ?>
    </div>
    <div class="col-lg-2">
        <p class="text-right"><a href="<?php echo e(route('banners.create')); ?>" class="btn btn-sm btn-primary"><i class="fa fa-fw fa-plus-circle"></i> <?php echo app('translator')->get('administracion.nuevo'); ?></a></p>
    </div>
</div>

<div class="row">
    <div class="col-lg-12"><!-- class tr active success warning danger -->
        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th><?php echo app('translator')->get('administracion.banners'); ?></th>
                        <th width="80"></th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr data-id='<?php echo e(codifica($banner->id)); ?>'>
                        <td><a href="<?php echo e(route('banners.edit', codifica($banner->id) )); ?>" title="<?php echo app('translator')->get('administracion.editar'); ?>"><?php echo e($banner->title); ?></a></td>
                        <td>
                            <a href="<?php echo e(route('banners.edit', codifica($banner->id) )); ?>" title="<?php echo app('translator')->get('administracion.editar'); ?>"><i class="fa fa-fw fa-edit"></i></a>
                            <a href="<?php echo e(route('banners_eliminar', codifica($banner->id) )); ?>" title="<?php echo app('translator')->get('administracion.eliminar'); ?>"><i class="fa fa-fw fa-ban bloquear"></i></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <?php echo e($banners->render()); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
<script type="text/javascript">
$(document).ready(function(){
    $(".bloquear").click(function(event){
        event.preventDefault();
        if(confirm("<?php echo app('translator')->get('administracion.confirmar_eliminar'); ?>")){
            document.location=$(this).parent().attr("href");
        }
    });
    setTimeout(function(){
        $(".alert").slideUp(500);
    },10000);
    $('tbody').sortable({
        stop: function( event, ui ) {
            ids=new Array();
            $('tbody tr').each(function(){
                ids.push($(this).data('id'));
            });
            $.ajax({
                'url' : "<?php echo e(route('ordena_banners')); ?>?ids=" + ids
            });
        }
    });
})
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\tienda_ananke\resources\views/administracion/banners/index.blade.php ENDPATH**/ ?>