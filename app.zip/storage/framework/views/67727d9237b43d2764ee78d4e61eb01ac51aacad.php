<section class="cu-catalog">
    <div class="cu-container">
        <div class="cu-catalog__intro">
            <h2>Parte del nuestro catálogo</h2>
            <p>Spring comforting pumpkin spice latte strawberry spinach salad kale caesar salad </p>
        </div>
        <div class="cu-catalog__slider">
           <div class="cu-catalog__slider__wrapper">
                <?php $__currentLoopData = $carros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carro_p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('partials._car_minicard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </div>
           <a href="<?php echo e(route('category')); ?>" class="cu-button cu-button--filled">Ver más</a>
        </div>
    </div>
</section><?php /**PATH D:\wamp64\www\carros_usados\resources\views/partials/_catalog_home.blade.php ENDPATH**/ ?>