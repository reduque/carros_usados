
<?php $__env->startSection('css'); ?>
    <link href="css/slim.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
     <div class="col-lg-6">
        <h1 class="page-header"><?php echo app('translator')->get('administracion.categories'); ?></h1>
    </div>
    <div class="col-lg-12">
        <ol class="breadcrumb">
            <li><a href="<?php echo e(route('administracion_home')); ?>"><i class="fa fa-dashboard"></i> <?php echo app('translator')->get('administracion.inicio'); ?></a></li>
            <li><a href="<?php echo e(route('categories.index')); ?>"><i class="fa fa-fw fa-pencil"></i> <?php echo app('translator')->get('administracion.categories'); ?></a></li>
            <li>Editar</li>
        </ol>
    </div>
</div>
<div class="row">
    <div class="col-lg-10">
    <?php if($notificacion=Session::get('notificacion')): ?>
        <div class="alert alert-success"><?php echo e($notificacion); ?></div>
    <?php endif; ?>
    <?php if($notificacion_error=Session::get('notificacion_error')): ?>
        <div class="alert alert-danger"><?php echo e($notificacion_error); ?></div>
    <?php endif; ?>
    </div>
    <div class="col-lg-2">
        <p class="text-right"><a href="<?php echo e(route('categories.index')); ?>" class="btn btn-sm btn-primary"><i class="fa fa-fw fa-list"></i> <?php echo app('translator')->get('administracion.volver_lista'); ?></a></p>
    </div>
</div>
<form role="form" action="<?php echo e(route('categories.update', codifica($category->id))); ?>" method="POST" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

    <?php echo e(method_field('PUT')); ?>


    <div class="row">
        <div class="col-lg-12">
            <div class="form-group<?php echo e($errors->has('nombre') ? ' has-error' : ''); ?>">
                <label>Categoría</label>
                <input type="text" class="form-control" name="nombre" value="<?php echo e(old('nombre', $category->nombre)); ?>" maxlength="100" required autofocus>
                <?php if($errors->has('nombre')): ?>
                    <p class="help-block"><?php echo e($errors->first('nombre')); ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-4">
            <div class="form-group">
                <label>Imagen</label>
                <div class="slim">
                    <input name="foto" type="file" accept="image/jpeg, image/png" />
                    <?php if($category->foto<>''): ?>
                        <img src="uploads/categorias/<?php echo e($category->foto); ?>">
                    <?php endif; ?>
                </div>
                <label><span>Tamaño mímino 640 x 640 px | JPG o PNG</span></label>
            </div>
        </div>
    </div>
    <h3>Metadata</h3>
    <div class="row">
        <div class="col-lg-6">
            <div class="form-group">
                <label>Title</label>
                <input type="text" class="form-control" name="meta_title" value="<?php echo e(old('meta_title',$category->meta_title)); ?>" maxlength="200">
            </div>
        </div>
        <div class="col-lg-6">
            <div class="form-group">
                <label>Keywords</label>
                <input type="text" class="form-control" name="meta_keywords" value="<?php echo e(old('meta_keywords',$category->meta_keywords)); ?>" maxlength="200">
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="form-group">
                <label>Description</label>
                <input type="text" class="form-control" name="meta_description" value="<?php echo e(old('meta_keywords',$category->meta_description)); ?>" maxlength="200">
            </div>
        </div>
    </div>
    
    <div class="row">
        <div class="col-lg-12">
            <button type="submit" class="btn btn-success"><i class="fa fa-fw fa-check"></i> <?php echo app('translator')->get('administracion.guardar'); ?></button>  
            <a href="<?php echo e(route('categories.index')); ?>" class="btn btn-primary"><i class="fa fa-fw fa-list"></i> <?php echo app('translator')->get('administracion.volver_lista'); ?></a> 
            <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-primary"><i class="fa fa-fw fa-plus-circle"></i> <?php echo app('translator')->get('administracion.nuevo'); ?></a> 
            <a href="<?php echo e(route('productos.index')); ?>" class="btn btn-primary"><i class="fa fa-fw fa-list"></i> <?php echo app('translator')->get('administracion.products'); ?></a> 
            <a href="<?php echo e(route('categories_eliminar', codifica($category->id) )); ?>" class="btn btn-danger"><i class="fa fa-fw fa-ban"></i> <?php echo app('translator')->get('administracion.eliminar'); ?></a>
        </div>
    </div>
</form>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>

<script type="text/javascript">
$(document).ready(function(){
    setTimeout(function(){
        $(".alert").slideUp(500);
    },10000)
    $(".btn-danger").click(function(event){
        event.preventDefault();
        if(confirm("<?php echo app('translator')->get('administracion.confirmar_eliminar'); ?>")){
            document.location=$(this).attr("href");
        }
    })
})
</script>

<script src="js/slim.jquery.js"></script>
<script type="text/javascript">
  $(document).ready(function(){
   $('.slim').slim({
      label: 'Arrastra tu imagen ó haz click aquí',
      ratio: '1:1',
      forceType: 'jpg',
      minSize: {
        width: 640,
        height: 640
      },
      size: {
        width: 640,
        height: 640
      },
      download: false,
      labelLoading: 'Cargando imagen...',
      statusImageTooSmall: 'La imagen es muy pequeña. El tamaño mínimo es $0 píxeles.',
      statusUnknownResponse: 'Ha ocurrido un error inesperado.',
      statusUploadSuccess: 'Imagen guardada',
      statusFileSize: 'El tamaño máximo de imagen es 1MB.',
      statusFileType: 'El formato de imagen no es permitido. Solamente: $0.',
      buttonConfirmLabel: 'Aceptar',
      buttonConfirmTitle: 'Aceptar',
      buttonCancelLabel: 'Cancelar',
      buttonCancelLabel: "Cancelar",
      buttonCancelTitle: "Cancelar",
      buttonEditTitle: "Editar",
      buttonRemoveTitle: "Eliminar",
      buttonRotateTitle: "Rotar",
      buttonUploadTitle: "Guardar"
    });
 })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\tienda_ananke\resources\views/administracion/categories/edit.blade.php ENDPATH**/ ?>