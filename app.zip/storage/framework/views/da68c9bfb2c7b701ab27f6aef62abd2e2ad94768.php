

<?php $__env->startSection('content'); ?>
    <div class="banners_home2">
        <div class="contenedor">
        <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item">
            <?php if($banner->link<>''): ?>
                <a href="<?php echo e($banner->link); ?>" target="_blank"><img src="uploads/banners/<?php echo e($banner->img); ?>" alt="<?php echo e($banner->title); ?>"></a>
            <?php else: ?>
                <img src="uploads/banners/<?php echo e($banner->img); ?>" alt="<?php echo e($banner->title); ?>">
            <?php endif; ?>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="cuerpo">
        <div class="info_home">
            <article>
                <img src="img/gluten.svg" alt="Libre de gluten">
                <h2>Libre de gluten</h2>
            </article>
            <article>
                <img src="img/alemania_diapo.svg" alt="EL verdadero sabor alemán">
                <h2>EL verdadero sabor alemán</h2>
            </article>
            <article>
                <img src="img/carne.svg" alt="Libre de gluten">
                <h2>Producto alto en proteinas</h2>
            </article>
        </div>
        <h2 class="h2home">
            Productos destacados
        </h2>
        <section class="productos_grid productos_grid_home">
            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('partials._card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </section>
    </div>
    <div class="cathomecont">
        <div class="cuerpo">
            <h2 class="h2home">
                Categorías
            </h2>
            <section class="cathome">
            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                    <a href="<?php echo e(route('categoria', $categoria->slug)); ?>">
                        <h2><?php echo e($categoria->nombre); ?></h2>
                        <img src="uploads/categorias/<?php echo e($categoria->foto); ?>" alt="">
                        <a href="<?php echo e(route('categoria', $categoria->slug)); ?>" class="vermas">Ver productos</a>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </section>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
    <script>
    <?php if($banners->count()>1): ?>
        var t;
        var act=0;
        const tot=<?php echo e($banners->count()); ?>;
        mostrar_banner=function(){
            clearTimeout(t);
            if(act != 0){
                $('.banners_home2 .item:nth-child(' + act + ')').fadeOut(500);
            }
            act++;
            if(act>tot) act=1;
            setTimeout(function(){
                $('.banners_home2 .item:nth-child(' + act + ')').fadeIn(500);
            },500);
            t=setTimeout(mostrar_banner, 5000);
        }
        $(window).load(function(){
            mostrar_banner();
        })
    <?php else: ?>
        $(window).load(function(){
            $('.banners_home2 .item').fadeIn(500);
        });
    <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\charcuteria_tovar\resources\views/home.blade.php ENDPATH**/ ?>