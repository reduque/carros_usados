

<?php $__env->startSection('content'); ?>

<div class="row">
     <div class="col-lg-6">
        <h1 class="page-header">Órdenes</h1>
    </div>
    <div class="col-lg-12">
        <ol class="breadcrumb">
            <li><a href="<?php echo e(route('administracion_home')); ?>"><i class="fa fa-dashboard"></i> <?php echo app('translator')->get('administracion.inicio'); ?></a></li>
            <li class="active"><i class="fa fa-fw fa-check-square"></i> Órdenes</li>
        </ol>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <form class="form-inline" action="<?php echo e(route("ordenes")); ?>" name="f_search" method="GET">
            <div class="form-group">
                <select class="form-control" name="status_filter">
                    <option value="">All</option>
                </select>
            </div>
            <div class="form-group">
                <input type="text" class="form-control" name="nombre" placeholder="Nombre del cliente">
            </div>
            <span class="form-group-btn">
            <button class="btn btn-primary" type="submit">Search</button>
            </span>
        </form>
    </div>
</div>
<p>&nbsp;</p>
<div class="row">
    <div class="col-lg-12"><!-- class tr active success warning danger -->
        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th>N. orden</th>
                        <th>Nombre</th>
                        <th>Cliente</th>
                        <th>Estado</th>
                        <th width="60"></th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $ordenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orden): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr data-id='<?php echo e(codifica($orden->id)); ?>'>
                        <td><a href="<?php echo e(route('ordene_detalle', codifica($orden->id) )); ?>" title="<?php echo app('translator')->get('administracion.editar'); ?>"><?php echo e(str_pad($orden->id,5,"0",STR_PAD_LEFT)); ?></a></td>
                        <td><a href="<?php echo e(route('ordene_detalle', codifica($orden->id) )); ?>" title="<?php echo app('translator')->get('administracion.editar'); ?>"><?php echo e($orden->fecha); ?></a></td>
                        <td><a href="<?php echo e(route('ordene_detalle', codifica($orden->id) )); ?>" title="<?php echo app('translator')->get('administracion.editar'); ?>"><?php echo e($orden->usuario->name); ?></a></td>
                        <td><a href="<?php echo e(route('ordene_detalle', codifica($orden->id) )); ?>" title="<?php echo app('translator')->get('administracion.editar'); ?>"><?php echo e($orden->estado_real); ?></a></td>
                        <td>
                            <a href="<?php echo e(route('ordene_detalle', codifica($orden->id) )); ?>" title="<?php echo app('translator')->get('administracion.editar'); ?>"><i class="fa fa-fw fa-edit"></i></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <?php echo e($ordenes->appends(Request::except('page'))->render()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\tienda_ananke\resources\views/administracion/productos/ordenes.blade.php ENDPATH**/ ?>