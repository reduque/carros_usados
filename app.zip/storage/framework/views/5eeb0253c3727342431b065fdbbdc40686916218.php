<!doctype html>

<html lang="es">
<head>
    <meta charset="utf-8">

    <title><?php if(View::hasSection('title')): ?> <?php echo $__env->yieldContent('title'); ?> <?php else: ?> <?php echo e(config('app.name', 'Laravel')); ?> <?php endif; ?> </title>
    <?php if(View::hasSection('keywords')): ?>
        <meta name="keywords" content="<?php echo $__env->yieldContent('keywords'); ?>" />
    <?php endif; ?>
    <?php if(View::hasSection('description')): ?>
        <meta name="description" content="<?php echo $__env->yieldContent('description'); ?>" />
    <?php endif; ?>


    <meta name="viewport" content="width=device-width, initial-scale=1">

    <base href="<?php echo e(asset('/')); ?>">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.14.0/css/all.css" integrity="sha384-HzLeBuhoNPvSl5KYnjx0BT+WB0QEEqLprO+NBkkk5gbc67FTaL7XIGa2w1L0Xbgc" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=MuseoModerno:wght@400;600;700&display=swap" rel="stylesheet">
    <link href="css/main.css?v?<?php echo e(rand()); ?>" rel="stylesheet">

    <?php echo $__env->yieldContent('css'); ?>
    
    <!-- IE -->
    <link rel="shortcut icon" type="image/x-icon" href="favicon.ico" />
    <!-- other browsers -->
    <link rel="icon" type="image/x-icon" href="favicon.ico" />
    <link rel="apple-touch-icon" sizes="180x180" href="apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">
    <link rel="manifest" href="site.webmanifest">
    <link rel="mask-icon" href="safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-ZCNN0JRGY8"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', 'G-ZCNN0JRGY8');
    </script>
</head>

<body>
    <header>
        <div class="cintillo">
            <div class="cuerpo">
                <div>
                    <a href="tel:+584125779940"><i class="fas fa-phone-alt"></i><span>0412-5779940</span></a> 
                    <a href="mailto:tienda@ananke.com.ve"><i class="fas fa-envelope"></i><span>tienda@ananke.com.ve</span></a>
                    <a href="https://www.ananke.com.ve/"><i class="fas fa-share-square"></i><span>ananke.com.ve</span></a>
                </div>
                <div>
                    <a href="https://www.instagram.com/anankequesos/" target="_blank"><i class="fab fa-instagram"></i></a>
                    <a href="https://wa.me/584125779940" target="_blank"><i class="fab fa-whatsapp"></i></a>
                </div>
            </div>
        </div>
        <div class="cabecera">
            <div class="cuerpo">
                <div>
                    <a href="<?php echo e(route('home')); ?>" class="logo"></a>
                </div>
                <div>
                    <?php if(auth()->guard()->guest()): ?>
                        <a href="<?php echo e(route('login')); ?>" title="Ingresar" class="noenmobile"><i class="fas fa-sign-in-alt"></i></a>
                        <a href="<?php echo e(route('register')); ?>" title="Registrarse" class="noenmobile"><i class="fas fa-user-plus"></i></a>
                    <?php else: ?>
                        <a href="" title="Mi perfil" class="noenmobile"><i class="fas fa-user"></i></a>
                        <a href="<?php echo e(route('logout')); ?>" title="Salir" class="noenmobile"><i class="fas fa-sign-out-alt"></i></a>
                    <?php endif; ?>
                    <a href="<?php echo e(route('shopping_cart')); ?>" title="Carrito de compras" class="noenmobile"><i class="fas fa-shopping-cart"></i></a>
                    <a href="" title="Buscar" class="buscar noenmobile"><i class="fas fa-search"></i></a>
                    <a href="#" class="hamburguesa" title="Menú"><i class="fas fa-bars"></i></a>
                </div>
            </div>
        </div>
        <div class="menu">
            <div class="cuerpo">
                <div>
                    <h2>categorías</h2>
                </div>
                <div>
                    <h2>secciones</h2>
                    <a href="<?php echo e(route('home')); ?>">Inicio</a>
                    <a href="" class="buscar">Buscar</a>

                    <!-- <a href="<?php echo e(route('home')); ?>">Sobre nosotros</a> -->
                    <a href="<?php echo e(route('tyc')); ?>">Términos de servicio</a>
                    <a href="<?php echo e(route('shopping_cart')); ?>">Carrito de compras</a>
                    <?php if(auth()->guard()->guest()): ?>
                        <a href="<?php echo e(route('login')); ?>">Ingresar</a>
                        <a href="<?php echo e(route('register')); ?>">Registrarse</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('mis_compras')); ?>">Mis compras</a>
                        <a href="<?php echo e(route('logout')); ?>">Salir</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="buscador">
            <div class="cuerpo">
                <div class="contenedor">
                    <form action="<?php echo e(route('productos')); ?>" method="GET">
                        <div class="row">
                            <div class="col-xs-10">
                                <input type="text" name="q" placeholder="Buscar" value="<?php echo e($q ?? ''); ?>" minlength="2" required>
                            </div>
                            <div class="col-xs-2 right">
                                <button><i class="fas fa-search"></i></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </header>
    <div class="cuerpo">
        <main>
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
    <footer>
        <div class="cuerpo">
            <img src="img/logo_diapo.svg" alt="">
            <div>
                <a href="mailto:tienda@ananke.com.ve">contáctanos</a> |
                <a href="<?php echo e(route('tyc')); ?>">términos de servicio</a>
            </div>
        </div>
    </footer>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
    <?php echo $__env->yieldContent('javascript'); ?>
    <script>
        $(document).ready(function(){
            $.get("<?php echo e(route('carga_categorias_menu')); ?>", function(data){
                $('.menu .cuerpo div:first-child').append(data.salida);
            });
            $('.hamburguesa').click(function(e){
                e.preventDefault();
                if($(this).hasClass('abierto')){
                    $('.menu').slideUp(300);
                    $(this).removeClass('abierto');
                }else{
                    $('.buscador').slideUp(300);
                    $('.buscar').removeClass('abierto');

                    $('.menu').slideDown(300);
                    $(this).addClass('abierto');
                }
            })
            $('.buscar').click(function(e){
                e.preventDefault();
                if($(this).hasClass('abierto')){
                    $('.buscador').slideUp(300);
                    $(this).removeClass('abierto');
                }else{
                    $('.menu').slideUp(300);
                    $('.hamburguesa').removeClass('abierto');

                    $('.buscador').slideDown(300);
                    $(this).addClass('abierto');
                }
            })

        })
    </script>
</body>
</html><?php /**PATH D:\wamp64\www\tienda_ananke\resources\views/layouts/front.blade.php ENDPATH**/ ?>