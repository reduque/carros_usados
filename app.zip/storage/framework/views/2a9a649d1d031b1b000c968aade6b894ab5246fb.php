

<?php $__env->startSection('content'); ?>

<div class="row">
     <div class="col-lg-6">
        <h1 class="page-header"><?php echo app('translator')->get('administracion.usuarios'); ?></h1>
    </div>
    <div class="col-lg-12">
        <ol class="breadcrumb">
            <li><a href="<?php echo e(route('administracion_home')); ?>"><i class="fa fa-dashboard"></i> 
<?php echo app('translator')->get('administracion.inicio'); ?></a></li>
            <li><a href="<?php echo e(route("usuarios.index")); ?>"><i class="fa fa-fw fa-user"></i> <?php echo app('translator')->get('administracion.usuarios'); ?></a></li>
            <li><?php echo app('translator')->get('administracion.cambiar_clave'); ?></li>
        </ol>
    </div>
</div>
<div class="row">
    <div class="col-lg-10">
    <?php if($notificacion=Session::get('notificacion')): ?>
        <div class="alert alert-success"><?php echo e($notificacion); ?></div>
    <?php endif; ?>
    </div>
    <div class="col-lg-2">
        <p class="text-right"><a href="<?php echo e(route('usuarios.index')); ?>" class="btn btn-sm btn-primary"><i class="fa fa-fw fa-list"></i> <?php echo app('translator')->get('administracion.volver_lista'); ?></a></p>
    </div>
</div>

<form role="form" action="<?php echo e(route('update_password', ['id' => codifica($usuario->id)])); ?>" method="POST">
    <?php echo e(csrf_field()); ?>

    <?php echo e(method_field('PUT')); ?>

    <?php echo e(csrf_field()); ?>

    <div class="row">
        <div class="col-lg-6">
            <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                <label><?php echo app('translator')->get('administracion.clave'); ?> (<?php echo e($usuario->name); ?>)</label>
                <input type="password" class="form-control" name="password" maxlength="100" required>
                <?php if($errors->has('password')): ?>
                    <p class="help-block"><?php echo e($errors->first('password')); ?></p>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="form-group">
                <label><?php echo app('translator')->get('administracion.confirmar_clave'); ?></label>
                <input type="password" class="form-control" name="password_confirmation" maxlength="100" required>
            </div>
        </div>
    </div>
    <div class="row"><div class="col-lg-6"><button type="submit" class="btn btn-success"><i class="fa fa-fw fa-check"></i> <?php echo app('translator')->get('administracion.guardar'); ?></button>  <a href="<?php echo e(route('usuarios.index')); ?>" class="btn btn-primary"><i class="fa fa-fw fa-list"></i> <?php echo app('translator')->get('administracion.volver_lista'); ?></a></div></div>
</form>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
    <script type="text/javascript">
        $(document).ready(function(){
            setTimeout(function(){
                $(".alert").slideUp(500);
            },3000)
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\tienda_ananke\resources\views/administracion/usuarios/edit_password.blade.php ENDPATH**/ ?>