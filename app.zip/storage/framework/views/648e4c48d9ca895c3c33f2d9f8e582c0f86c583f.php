

<?php $__env->startSection('css'); ?>
    <link href="css/slim.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
     <div class="col-lg-6">
        <h1 class="page-header"><?php echo app('translator')->get('administracion.carros'); ?></h1>
    </div>
    <div class="col-lg-12">
        <ol class="breadcrumb">
            <li><a href="<?php echo e(route('administracion_home')); ?>"><i class="fa fa-dashboard"></i> <?php echo app('translator')->get('administracion.inicio'); ?></a></li>
            <li><a href="<?php echo e(route('marcas.edit', codifica($marca->id))); ?>"><i class="fa fa-fw fa-pencil"></i> <?php echo e($marca->marca); ?></a></li>
            <li><a href="<?php echo e(route("modelos.index")); ?>"><i class="fa fa-fw fa-pencil"></i> <?php echo app('translator')->get('administracion.carros'); ?></a></li>
            <li><?php echo app('translator')->get('administracion.crear'); ?></li>
        </ol>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <p class="text-right"><a href="<?php echo e(route('modelos.index')); ?>" class="btn btn-sm btn-primary"><i class="fa fa-fw fa-list"></i> <?php echo app('translator')->get('administracion.volver_lista'); ?></a></p>
    </div>
</div>

<form role="form" action="<?php echo e(route('modelos.store')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

    <input type="hidden" name="marca_id" value="<?php echo e($marca->id); ?>">
    <div class="row">
        <div class="col-lg-12">
            <div class="form-group<?php echo e($errors->has('modelo') ? ' has-error' : ''); ?>">
                <label>Modelo</label>
                <input type="text" class="form-control" name="modelo" value="<?php echo e(old('modelo')); ?>" maxlength="50" required autofocus>
                <?php if($errors->has('modelo')): ?>
                    <p class="help-block"><?php echo e($errors->first('modelo')); ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <div class="row">
        <div class="col-lg-12">
            <button type="submit" class="btn btn-success"><i class="fa fa-fw fa-check"></i> <?php echo app('translator')->get('administracion.guardar'); ?></button>  
            <a href="<?php echo e(route('modelos.index')); ?>" class="btn btn-primary"><i class="fa fa-fw fa-list"></i> <?php echo app('translator')->get('administracion.volver_lista'); ?></a>
        </div>
    </div>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\carros_usados\resources\views/administracion/modelos/create.blade.php ENDPATH**/ ?>