

<?php if($categoria->meta_title): ?>
    <?php $__env->startSection('title',$categoria->meta_title); ?>
<?php endif; ?>
<?php if($categoria->meta_description): ?>
    <?php $__env->startSection('description',$categoria->meta_description); ?>
<?php endif; ?>
<?php if($categoria->meta_keywords): ?>
    <?php $__env->startSection('keywords',$categoria->meta_keywords); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
<div class="bint">
    <img src="uploads/categorias/<?php echo e($categoria->banner); ?>" alt="<?php echo e($categoria->nombre); ?>">
</div>
<div class="cuerpo">
    <h1 class="h2home"><?php echo e($categoria->nombre); ?></h1>
    <div class="espaciado">
        <section class="productos_grid">
            <?php $__currentLoopData = $categoria->productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('partials._card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\charcuteria_tovar\resources\views/categoria.blade.php ENDPATH**/ ?>