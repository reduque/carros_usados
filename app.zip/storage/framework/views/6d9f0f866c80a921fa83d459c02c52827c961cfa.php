

<?php if($categoria->meta_title): ?>
    <?php $__env->startSection('title',$categoria->meta_title); ?>
<?php endif; ?>
<?php if($categoria->meta_description): ?>
    <?php $__env->startSection('description',$categoria->meta_description); ?>
<?php endif; ?>
<?php if($categoria->meta_keywords): ?>
    <?php $__env->startSection('keywords',$categoria->meta_keywords); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
<div class="internas">
    <h1><?php echo e($categoria->nombre); ?></h1>
    <div class="espaciado">
        <section class="productos">
            <h2 class="centrado_m_1">productos</h2>
            <div class="contenedor">
            <?php $__currentLoopData = $categoria->productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('partials._card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\tienda_ananke\resources\views/categoria.blade.php ENDPATH**/ ?>