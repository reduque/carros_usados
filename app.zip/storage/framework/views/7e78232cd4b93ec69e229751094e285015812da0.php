

<?php $__env->startSection('content'); ?>
<hr>
<div class="cuerpo">
    <h1 class="h2home">
    <?php if($q <> ''): ?>
        Filtro: <?php echo e($q); ?>

    <?php else: ?>
        todos los productos
    <?php endif; ?>
    </h1>
    <div class="espaciado">
        <section class="productos_grid">
            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('partials._card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </section>
        <div class="separador"></div>
        <br>
        <div class="row">
            <div class="col-lg-12">
                <?php echo e($productos->appends(Request::except('page'))->render()); ?>

            </div>
        </div>
        
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\charcuteria_tovar\resources\views/productos.blade.php ENDPATH**/ ?>