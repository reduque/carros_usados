

<?php $__env->startSection('css'); ?>
    <link href="css/slim.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
     <div class="col-lg-6">
        <h1 class="page-header"><?php echo app('translator')->get('administracion.carros'); ?></h1>
    </div>
    <div class="col-lg-12">
        <ol class="breadcrumb">
            <li><a href="<?php echo e(route('administracion_home')); ?>"><i class="fa fa-dashboard"></i> <?php echo app('translator')->get('administracion.inicio'); ?></a></li>
            <li><a href="<?php echo e(route("carros.index")); ?>"><i class="fa fa-fw fa-pencil"></i> <?php echo app('translator')->get('administracion.carros'); ?></a></li>
            <li><?php echo app('translator')->get('administracion.crear'); ?></li>
        </ol>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <p class="text-right"><a href="<?php echo e(route('carros.index')); ?>" class="btn btn-sm btn-primary"><i class="fa fa-fw fa-list"></i> <?php echo app('translator')->get('administracion.volver_lista'); ?></a></p>
    </div>
</div>

<form role="form" action="<?php echo e(route('carros.store')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

    <div class="row">
        <div class="col-lg-3">
            <div class="form-group">
                <label>Marca</label>
                <select name="marca_id" class="form-control" required>
                    <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($marca->id); ?>" <?php if(old('marca_id') == $marca->id): ?> selected <?php endif; ?> ><?php echo e($marca->marca); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="form-group">
                <label>Modelo</label>
                <select name="modelo_id" class="form-control" required></select>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="form-group">
                <label>Año</label>
                <select name="ano" class="form-control">
                    <?php for($l=date('Y')-20; $l<=date('Y'); $l++): ?>
                        <option value="<?php echo e($l); ?>" <?php if(old('ano') == $l): ?> selected <?php endif; ?> ><?php echo e($l); ?></option>
                    <?php endfor; ?>
                </select>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="form-group<?php echo e($errors->has('placa') ? ' has-error' : ''); ?>">
                <label>Placa</label>
                <input type="text" class="form-control" name="placa" value="<?php echo e(old('placa')); ?>" maxlength="15" required>
                <?php if($errors->has('placa')): ?>
                    <p class="help-block"><?php echo e($errors->first('placa')); ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="form-group">
                <label>Descripción (colocar cada item en una línea diferente)</label>
                <textarea class="form-control" rows="5" name="descripcion" required><?php echo e(old('descripcion')); ?></textarea>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-3">
            <div class="form-group<?php echo e($errors->has('precio') ? ' has-error' : ''); ?>">
                <label>Precio (USD)</label>
                <input type="number" class="form-control" name="precio" value="<?php echo e(old('precio')); ?>" min="0" step="1" required>
                <?php if($errors->has('precio')): ?>
                    <p class="help-block"><?php echo e($errors->first('precio')); ?></p>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="form-group<?php echo e($errors->has('color') ? ' has-error' : ''); ?>">
                <label>Color</label>
                <input type="text" class="form-control" name="color" value="<?php echo e(old('color')); ?>" maxlength="50" required>
                <?php if($errors->has('color')): ?>
                    <p class="help-block"><?php echo e($errors->first('color')); ?></p>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="form-group<?php echo e($errors->has('kilometraje') ? ' has-error' : ''); ?>">
                <label>Kilometraje</label>
                <input type="number" class="form-control" name="kilometraje" value="<?php echo e(old('kilometraje')); ?>" min="0" max="16777215" step="1" required>
                <?php if($errors->has('kilometraje')): ?>
                    <p class="help-block"><?php echo e($errors->first('kilometraje')); ?></p>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="form-group">
                <label>Transmisión</label>
                <select name="transmision" class="form-control" required>
                    <?php $__currentLoopData = array_transmision(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transmision): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($transmision); ?>" <?php if(old('transmision') == $transmision): ?> selected <?php endif; ?> ><?php echo e($transmision); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-3">
            <div class="form-group">
                <label>Tracción</label>
                <select name="traccion" class="form-control" required>
                    <?php $__currentLoopData = array_traccion(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $traccion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($traccion); ?>" <?php if(old('traccion') == $traccion): ?> selected <?php endif; ?> ><?php echo e($traccion); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="form-group">
                <label>Combustible</label>
                <select name="combustible" class="form-control" required>
                    <?php $__currentLoopData = array_combustible(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $combustible): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($combustible); ?>" <?php if(old('combustible') == $combustible): ?> selected <?php endif; ?> ><?php echo e($combustible); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="form-group<?php echo e($errors->has('tanque_de_combustible') ? ' has-error' : ''); ?>">
                <label>Tanque de combustible: # lts</label>
                <input type="number" class="form-control" name="tanque_de_combustible" value="<?php echo e(old('tanque_de_combustible')); ?>" min="0" max="255" step="1" required>
                <?php if($errors->has('tanque_de_combustible')): ?>
                    <p class="help-block"><?php echo e($errors->first('tanque_de_combustible')); ?></p>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="form-group<?php echo e($errors->has('puertas') ? ' has-error' : ''); ?>">
                <label>Puertas</label>
                <input type="number" class="form-control" name="puertas" value="<?php echo e(old('puertas')); ?>" min="0" max="5" step="1" required>
                <?php if($errors->has('puertas')): ?>
                    <p class="help-block"><?php echo e($errors->first('puertas')); ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-3">
            <div class="form-group">
                <label>Asientos</label>
                <select name="asientos" class="form-control" required>
                    <?php $__currentLoopData = array_asientos(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asientos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($asientos); ?>" <?php if(old('asientos') == $asientos): ?> selected <?php endif; ?> ><?php echo e($asientos); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="form-group">
                <br>
                <input type="checkbox" class="" name="aire_acondicionado" id="aire_acondicionado" value="1" <?php if(old('aire_acondicionado')==1): ?> checked <?php endif; ?> >&nbsp;&nbsp;<label for="aire_acondicionado">Aire acondicionado</label>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="form-group<?php echo e($errors->has('juegos_de_llaves') ? ' has-error' : ''); ?>">
                <label>Juegos de llaves</label>
                <input type="number" class="form-control" name="juegos_de_llaves" value="<?php echo e(old('juegos_de_llaves')); ?>" min="0" max="5" step="1" required>
                <?php if($errors->has('juegos_de_llaves')): ?>
                    <p class="help-block"><?php echo e($errors->first('juegos_de_llaves')); ?></p>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="form-group">
                <br>
                <input type="checkbox" class="" name="sistema_de_seguroda" id="sistema_de_seguroda" value="1" <?php if(old('sistema_de_seguroda')==1): ?> checked <?php endif; ?> >&nbsp;&nbsp;<label for="sistema_de_seguroda">Sistema de seguroda</label>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-6">
            <div class="form-group">
                <label>Imagen pincipal</label>
                <div class="slim">
                    <input name="img" type="file" accept="image/jpeg, image/png" />
                </div>
                <label><span>Tamaño mímino 2500 x 1400 px | JPG o PNG</span></label>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="form-group">
                <input type="checkbox" class="" name="aire_acondicionado" id="a_a" value="1" <?php if( old('aire_acondicionado',1) == 1 ): ?> checked <?php endif; ?> >&nbsp;&nbsp;<label for="a_a">Activo</label>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <button type="submit" class="btn btn-success"><i class="fa fa-fw fa-check"></i> <?php echo app('translator')->get('administracion.guardar'); ?></button>  
            <a href="<?php echo e(route('carros.index')); ?>" class="btn btn-primary"><i class="fa fa-fw fa-list"></i> <?php echo app('translator')->get('administracion.volver_lista'); ?></a>
        </div>
    </div>
</form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>

<script src="js/slim.jquery.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
        $('.slim').slim({
            label: 'Arrastra tu imagen ó haz click aquí',
            ratio: '2500:1400',
            forceType: 'jpg',
            minSize: {
                width: 2500,
                height: 1400
            },
            size: {
                width: 2500,
                height: 1400
            },
            download: false,
            labelLoading: 'Cargando imagen...',
            statusImageTooSmall: 'La imagen es muy pequeña. El tamaño mínimo es $0 píxeles.',
            statusUnknownResponse: 'Ha ocurrido un error inesperado.',
            statusUploadSuccess: 'Imagen guardada',
            statusFileSize: 'El tamaño máximo de imagen es 1MB.',
            statusFileType: 'El formato de imagen no es permitido. Solamente: $0.',
            buttonConfirmLabel: 'Aceptar',
            buttonConfirmTitle: 'Aceptar',
            buttonCancelLabel: 'Cancelar',
            buttonCancelLabel: "Cancelar",
            buttonCancelTitle: "Cancelar",
            buttonEditTitle: "Editar",
            buttonRemoveTitle: "Eliminar",
            buttonRotateTitle: "Rotar",
            buttonUploadTitle: "Guardar"
        });

        function carros_modelos(){
            $.ajax({
                url: '<?php echo e(route('carros_modelos')); ?>',
                data: {
                    idmarca: $('select[name="marca_id"]').val(),
                    modeloid: '<?php echo e(old('modelo_id')); ?>'
                },
                type: "get",
                datatype: "html"
            }).done(function(data) {
                $('select[name="modelo_id"]').html(data);
            });
        }
        carros_modelos();
        $('select[name="marca_id"]').change(function(){
            carros_modelos();
        })
    })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\carros_usados\resources\views/administracion/carros/create.blade.php ENDPATH**/ ?>