<section class="cu-cert">
    <div class="cu-container">
        <div class="cu-cert__content">
            <div class="cu-cert__content__left">
                <h2>Certificación de condición técnica</h2>
                <p>Le realizamos al vehículo una rigurosa inspección de 150 puntos para que esté informado de todos los detalles que tiene el auto. <strong>No encontrarás sorpresas debajo del capot.</strong></p>
            </div>
            <img class="cu-cert__content__image" src="img/content/carros-usados-blueprint.png" alt="Certificación de condición técnica" />
        </div>
    </div>
</section><?php /**PATH D:\wamp64\www\carros_usados\resources\views/partials/_cert_home.blade.php ENDPATH**/ ?>