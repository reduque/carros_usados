

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">
            <?php echo app('translator')->get('administracion.inicio'); ?>
        </h1>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <p><?php echo app('translator')->get('administracion.bienvenida'); ?> <b><?php echo e(config('app.name', 'Laravel')); ?></b></p>
        <p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\tienda_ananke\resources\views/administracion/home.blade.php ENDPATH**/ ?>