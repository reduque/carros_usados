

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="cu-single">
        <div class="cu-container cu-container--single">
            <figure class="cu-single__feature">
                <img src="uploads/carros/<?php echo e($carro->img); ?>" alt="<?php echo e($carro->marca->marca . ' ' . $carro->modelo->modelo . ' ' . $carro->ano); ?>">
            </figure>
            <div class="cu-single__content">
                <div id="cu-single-info" class="cu-single__info" aria-hidden="false">
                    <button class="cu-single__info__button" aria-controls="cu-single-info" aria-expanded="true">
                        <span class="close">Cerrar</span>
                        <span class="open">Abrir</span>
                    </button>
                    <h2 class="cu-single__info__model"><?php echo e($carro->modelo->modelo); ?></h2>
                    <div class="cu-single__info__meta">
                        <p><span class="cu-single__info__meta__brand"><?php echo e(ucfirst(strtolower($carro->marca->marca))); ?></span>
                        <span class="cu-single__info__meta__year">&nbsp;<?php echo e($carro->ano); ?></span></p>
                        <p><?php echo e(number_format($carro->kilometraje,0,'.','.')); ?> km</p>
                    </div>
                    <div class="cu-single__info__footer">
                        <span class="cu-single__info__footer__price"><?php echo e(number_format($carro->precio,0,'.','.')); ?></span>
                        <a href="" class="cu-button cu-button--filled reserve-btn">Me interesa</a>
                    </div>
                    <ul class="cu-single__info__extras">
                        <?php echo nl2li($carro->descripcion); ?>

                    </ul>
                    <ul class="cu-single__info__specs">
                        <li>
                            <h5>Color</h5>
                            <span><?php echo e(ucfirst(strtolower($carro->color))); ?></span>
                        </li>
                        <li>
                            <h5>Transmisión</h5>
                            <span><?php echo e($carro->transmision); ?></span>
                        </li>
                        <li>
                            <h5>Tracción</h5>
                            <span><?php echo e($carro->traccion); ?></span>
                        </li>
                        <li>
                            <h5>Combustible</h5>
                            <span><?php echo e($carro->combustible); ?></span>
                        </li>
                        <li>
                            <h5>Tanque de combustible</h5>
                            <span><?php echo e($carro->tanque_de_combustible); ?> lts</span>
                        </li>
                        <li>
                            <h5>Puertas</h5>
                            <span><?php echo e($carro->puertas); ?></span>
                        </li>
                        <li>
                            <h5>Asientos</h5>
                            <span><?php echo e($carro->asientos); ?></span>
                        </li>
                        <li>
                            <h5>Aire acondicionado</h5>
                            <span><?php echo e(($carro->aire_acondicionado) ? 'Si' : 'No'); ?></span>
                        </li>
                        <li>
                            <h5>Juegos de llaves</h5>
                            <span><?php echo e($carro->juegos_de_llaves); ?></span>
                        </li>
                        <li>
                            <h5>Sistema de seguroda</h5>
                            <span><?php echo e(($carro->sistema_de_seguroda) ? 'Si' : 'No'); ?></span>
                        </li>
                    </ul>
                    <ul class="cu-single__info__actions">
                        <li>
                            <h3>Agenda<br />una cita</h3>
                            <p>Parsley açai frosted gingerbread bites vine tomatoes avocado dressing drizzle grains.</p>
                        </li>
                        <li>
                            <h3>Nuestros carros<br />Tienen garantía</h3>
                            <p>Parsley açai frosted gingerbread bites vine tomatoes avocado dressing drizzle grains.</p>
                        </li>
                        <li>
                            <h3>Revisión de 150 puntos</h3>
                            <p>Revisa el resultado de la evaluación de este carro</p>
                            <button class="see-points">Haz clic aquí</button>
                        </li>
                    </ul>
                    <div class="cu-single__info__times">
                        <h3>Horario de antención</h3>
                        <p>Citas para revisar los carros en persona se llevan a cabo de:</p>
                        <h5>Lunes a Sábado de 9:00m - 6pm</h5>
                    </div>
                </div>
                <div class="cu-single__gallery">
                    <div class="cu-single__gallery__main">
                        <?php $__currentLoopData = $carro->fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <figure class="cu-single__gallery__main__item gallery-item">
                                <a href="uploads/carros/galeria/<?php echo e($foto->img); ?>" data-fancybox="gallery">
                                    <img src="uploads/carros/galeria/<?php echo e($foto->img); ?>" alt="<?php echo e($carro->marca->marca . ' ' . $carro->modelo->modelo . ' ' . $carro->ano); ?>" />
                                </a>
                            </figure>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="cu-single__gallery__thumbs">
                        <?php $__currentLoopData = $carro->fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="cu-single__gallery__thumbs__thumb gallery-thumb">
                                <figure>
                                    <img src="uploads/carros/galeria/<?php echo e($foto->miniatura); ?>" alt="<?php echo e($carro->marca->marca . ' ' . $carro->modelo->modelo . ' ' . $carro->ano); ?>" />
                                </figure>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <?php echo $__env->make('partials._related', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </section>
    <?php echo $__env->make('partials._modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\carros_usados\resources\views/single.blade.php ENDPATH**/ ?>